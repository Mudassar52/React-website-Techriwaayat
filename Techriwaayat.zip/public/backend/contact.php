<?php
// Contact form handler for Hostinger (uses PHP mail()). Receives JSON from the React forms.
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['message' => 'Method not allowed']); exit; }

$TO   = 'TeamTechRiwaayat@gmail.com';
$FROM = 'no-reply@techriwaayat.com'; // must be a mailbox on your Hostinger domain for best delivery

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!empty($in['website'])) { echo json_encode(['message' => 'OK']); exit; } // honeypot

$clean = function ($v, $max = 2000) { return trim(mb_substr(strip_tags((string)($v ?? '')), 0, $max)); };
$name = $clean($in['name'] ?? '', 120); $email = $clean($in['email'] ?? '', 160);
$phone = $clean($in['phone'] ?? '', 40); $service = $clean($in['service'] ?? '', 120);
$subject = $clean($in['subject'] ?? '', 160); $message = $clean($in['message'] ?? '', 4000);
$page = $clean($in['page'] ?? '', 200);

if ($name === '' || $message === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(422); echo json_encode(['message' => 'Please enter your name, a valid email and a message.']); exit;
}
// Basic rate limit: 1 request / 20s per IP
$f = sys_get_temp_dir() . '/tr_' . md5($_SERVER['REMOTE_ADDR'] ?? 'x');
if (file_exists($f) && time() - filemtime($f) < 20) { http_response_code(429); echo json_encode(['message' => 'Please wait a few seconds and try again.']); exit; }
touch($f);

$body = "New website enquiry\n\nName: $name\nEmail: $email\nPhone: $phone\nService: $service\nSubject: $subject\nPage: $page\n\nMessage:\n$message\n";
$headers = "From: Tech Riwaayat <$FROM>\r\nReply-To: $name <$email>\r\nContent-Type: text/plain; charset=UTF-8\r\n";
$ok = mail($TO, '=?UTF-8?B?' . base64_encode('New enquiry: ' . ($service ?: 'Website') . ' - ' . $name) . '?=', $body, $headers);

if ($ok) { echo json_encode(['message' => 'Sent']); }
else { http_response_code(500); echo json_encode(['message' => 'Could not send right now. Please WhatsApp us on +92 3263 555252.']); }
