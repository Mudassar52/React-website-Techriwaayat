# Hostinger Deploy (Tech Riwaayat)

1. `npm install` then `npm run build` (build ke baad prerender + sitemap khud ban jata hai).
2. `dist/` folder ke andar ki SAARI files (hidden `.htaccess` samet) Hostinger `public_html/` mein upload karo.
3. `public_html/backend/contact.php` mein `$FROM` ko apne domain ki mailbox (e.g. no-reply@techriwaayat.com) se badlo.
4. Test: /contact form bhejo, mail Gmail mein aani chahiye. Ghalat URL par 404 page aana chahiye.
5. Google Search Console: domain add karo, verification meta `index.html` mein lagao, `https://techriwaayat.com/sitemap.xml` submit karo.
6. Google Analytics: `.env.production` mein `VITE_GA_ID=G-XXXXXXXXXX` rakho aur dubara build karo.

## Content jo aap ne khud add karna hai
- `src/data/caseStudies.js` mein real projects (portfolio tab tak hidden/noindex rahega).
- `src/config/site.js` mein city/phone/email (abhi Lahore set hai).
- `src/data/blogPosts.js` mein har hafte naye articles.
- `src/data/seoPages.js` mein naye keyword pages.
