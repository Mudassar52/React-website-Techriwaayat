HOW TO ADD YOUR OWN IMAGES
===========================

This folder holds the 3 images used on the Business Software page
(Dashboard, Reports, Invoice sections).

Just replace these 3 files with your own screenshots — SAME FILE NAME,
same folder. No code changes needed, the website will pick them up
automatically.

1. dashboard.jpg   -> Business dashboard screenshot
2. reports.jpg     -> Reports / analytics screenshot
3. invoice.jpg     -> Invoice / billing screenshot

RECOMMENDED SIZE:
- Width:  1200px (or larger)
- Height: 500px (wide, short image works best — not a tall/square screenshot)
- Format: .jpg or .png (if you use .png, also update the file extension
  in src/pages/BusinessSoftwarePage.jsx for that image)

That's it — save your file into this folder with the exact name above,
and it will replace the placeholder automatically on the live site.
