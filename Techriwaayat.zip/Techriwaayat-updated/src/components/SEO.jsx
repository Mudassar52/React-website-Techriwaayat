import React from 'react'
import { Helmet } from 'react-helmet-async'

const SITE_NAME = 'Tech Riwaayat'
const SITE_URL = 'https://techriwaayat.com'
const DEFAULT_IMAGE = `${SITE_URL}/og-image.png`

/**
 * Drop this at the top of any page component to control that page's
 * <title>, meta description, canonical URL, Open Graph & Twitter tags,
 * and (optionally) JSON-LD structured data.
 *
 * Usage:
 *   <SEO
 *     title="Business & POS Software Development"
 *     description="Custom POS, retail, wholesale, clinic..."
 *     path="/services/business-software"
 *   />
 */
const SEO = ({
  title,
  description,
  path = '/',
  image = DEFAULT_IMAGE,
  type = 'website',
  noindex = false,
  jsonLd = null,
}) => {
  const fullTitle = title ? `${title} | ${SITE_NAME}` : `${SITE_NAME} | Premier Digital & AI Automation Agency`
  const canonical = `${SITE_URL}${path}`

  return (
    <Helmet>
      <title>{fullTitle}</title>
      {description && <meta name="description" content={description} />}
      <link rel="canonical" href={canonical} />
      {noindex && <meta name="robots" content="noindex, nofollow" />}

      {/* Open Graph */}
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content={SITE_NAME} />
      <meta property="og:title" content={fullTitle} />
      {description && <meta property="og:description" content={description} />}
      <meta property="og:url" content={canonical} />
      <meta property="og:image" content={image} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      {description && <meta name="twitter:description" content={description} />}
      <meta name="twitter:image" content={image} />

      {jsonLd && (
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      )}
    </Helmet>
  )
}

export default SEO
