import React, { useEffect, Suspense, lazy } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AOS from 'aos'
import 'aos/dist/aos.css'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'

const AboutPage = lazy(() => import('./pages/AboutPage'))
const ContactPage = lazy(() => import('./pages/ContactPage'))
const TeamPage = lazy(() => import('./pages/TeamPage'))
const CareerPage = lazy(() => import('./pages/CareerPage'))
const CompanyPage = lazy(() => import('./pages/CompanyPage'))
const WebDevelopmentPage = lazy(() => import('./pages/WebDevelopmentPage'))
const MobileAppDevelopmentPage = lazy(() => import('./pages/MobileAppDevelopmentPage'))
const ECommerceDevelopmentPage = lazy(() => import('./pages/ECommerceDevelopmentPage'))
const AiAutomationPage = lazy(() => import('./pages/AiAutomationPage'))
const CustomSoftwarePage = lazy(() => import('./pages/CustomSoftwarePage'))
const BusinessSoftwarePage = lazy(() => import('./pages/BusinessSoftwarePage'))
const SeoOptimizationPage = lazy(() => import('./pages/SeoOptimizationPage'))
const WordpressDevelopmentPage = lazy(() => import('./pages/WordpressDevelopmentPage'))
const BlogPage = lazy(() => import('./pages/BlogPage'))
const BlogPostPage = lazy(() => import('./pages/BlogPostPage'))

const PageLoader = () => (
  <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <div style={{ width: 40, height: 40, border: '3px solid #e5e7eb', borderTopColor: '#00d97e', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
)

function App() {
  useEffect(() => {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
    })

    // Re-measure animation positions once everything (images, fonts, etc.)
    // has fully finished loading, so slow connections don't leave the
    // layout looking broken/misaligned.
    const handleLoad = () => AOS.refreshHard()
    if (document.readyState === 'complete') {
      handleLoad()
    } else {
      window.addEventListener('load', handleLoad)
    }
    return () => window.removeEventListener('load', handleLoad)
  }, [])

  return (
    <BrowserRouter>
      <div className="App">
        <Navbar />
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/team" element={<TeamPage />} />
            <Route path="/career" element={<CareerPage />} />
            <Route path="/company" element={<CompanyPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:id" element={<BlogPostPage />} />
            <Route path="/services/web-development" element={<WebDevelopmentPage />} />
            <Route path="/services/mobile-app-development" element={<MobileAppDevelopmentPage />} />
            <Route path="/services/e-commerce-development" element={<ECommerceDevelopmentPage />} />
            <Route path="/services/ai-automation" element={<AiAutomationPage />} />
            <Route path="/services/custom-software" element={<CustomSoftwarePage />} />
            <Route path="/services/business-software" element={<BusinessSoftwarePage />} />
            <Route path="/services/seo-optimization" element={<SeoOptimizationPage />} />
            <Route path="/services/wordpress-development" element={<WordpressDevelopmentPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </Suspense>
        <Footer />
      </div>
    </BrowserRouter>
  )
}

export default App
