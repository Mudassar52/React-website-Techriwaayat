import React from 'react'
import Hero from '../components/Hero'
import Clients from '../components/Clients'
import Services from '../components/Services'
import Industries from '../components/Industries'
import About from '../components/About'
import TechStack from '../components/TechStack'
import CTA from '../components/CTA'
import Process from '../components/Process'
import TeamPreview from '../components/TeamPreview'
import Pricing from '../components/Pricing'
import FAQ from '../components/FAQ'
import Contact from '../components/Contact'
import SEO from '../components/SEO'

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Tech Riwaayat',
  url: 'https://techriwaayat.com',
  logo: 'https://techriwaayat.com/favicon.png',
  description: 'Tech Riwaayat is a digital agency offering custom Web Development, Mobile App Development, AI Automation, Business & POS Software, and WordPress solutions.',
  address: {
    '@type': 'PostalAddress',
    addressLocality: 'Faisalabad',
    addressRegion: 'Punjab',
    addressCountry: 'PK',
  },
  sameAs: [],
}

const Home = () => {
  return (
    <div className="home-page">
      <SEO
        title={null}
        description="Tech Riwaayat is a leading digital agency offering custom Web Development, Mobile App Development, AI Automation, Business & POS Software, and WordPress solutions to grow your business."
        path="/"
        jsonLd={organizationJsonLd}
      />
      <Hero />
      <Clients />
      <Services />
      <Industries />
      <About />
      <TechStack />
      <CTA />
      <Process />
      <TeamPreview />
      <Pricing />
      <FAQ />
      <Contact />
    </div>
  )
}

export default Home
