// Single source of truth for business details (used by UI, schema and prerender script).
// Agar city/phone/email badalna ho to sirf yahan badlo.
export const SITE = {
  name: 'Tech Riwaayat',
  url: 'https://techriwaayat.com',
  email: 'TeamTechRiwaayat@gmail.com',
  phoneDisplay: '+92 3263 555252',
  phoneE164: '+923263555252',
  whatsapp: '923263555252',
  city: 'Lahore',
  region: 'Punjab',
  country: 'PK',
  social: [
    'https://www.facebook.com/people/TechRiwaayat/61588163576240/',
    'https://www.linkedin.com/company/tech-riwaayat/',
    'https://www.instagram.com/techriwaayat/',
  ],
  cities: ['Lahore', 'Karachi', 'Islamabad', 'Rawalpindi', 'Faisalabad', 'Multan', 'Peshawar', 'Sialkot', 'Gujranwala'],
}
export const waLink = (text = 'Hi Tech Riwaayat, I would like to discuss a software project.') =>
  `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(text)}`
