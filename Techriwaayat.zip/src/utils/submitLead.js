// Shared lead submission (Hostinger PHP endpoint: /backend/contact.php)
export async function submitLead(payload) {
  try {
    const res = await fetch('/backend/contact.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, page: window.location.pathname }),
    })
    const data = await res.json().catch(() => ({}))
    if (res.ok) return { ok: true }
    return { ok: false, message: data.message || 'Something went wrong. Please try again or WhatsApp us.' }
  } catch {
    return { ok: false, message: 'Network error. Please try again or contact us on WhatsApp.' }
  }
}
