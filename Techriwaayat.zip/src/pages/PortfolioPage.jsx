import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import SEO, { breadcrumbLd } from '../components/SEO'
import { caseStudies } from '../data/caseStudies'
import './LandingPage.css'

const PortfolioPage = () => {
  useEffect(() => { window.scrollTo(0, 0) }, [])
  const has = caseStudies.length > 0
  return (
    <div className="lp">
      <SEO title="Portfolio & Case Studies | Tech Riwaayat" fullTitle noindex={!has}
        description="Software, POS, web and app projects delivered by Tech Riwaayat, with the problem, solution and results for each."
        path="/portfolio" jsonLd={breadcrumbLd([{ name: 'Home', path: '/' }, { name: 'Portfolio', path: '/portfolio' }])} />
      <header className="lp-hero"><span className="lp-badge">PORTFOLIO</span><h1>Projects & Case Studies</h1>
        <p className="lp-lead">{has ? 'Real problems, real systems, measurable results.' : 'Our case studies are being prepared. Contact us for a live demo of similar work.'}</p></header>
      <div className="lp-wrap" style={{ paddingBottom: 60 }}>
        <div className="lp-grid">
          {caseStudies.map(c => (
            <Link to={`/portfolio/${c.slug}`} className="lp-card" key={c.slug}><h3>{c.title}</h3><p>{c.summary}</p></Link>
          ))}
        </div>
      </div>
    </div>
  )
}
export default PortfolioPage
