import React, { useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { FaCalendarAlt, FaUserEdit, FaArrowLeft } from 'react-icons/fa'
import AOS from 'aos'
import './BlogPostPage.css'
import SEO, { breadcrumbLd } from '../components/SEO'
import NotFound from './NotFound'
import { blogBySlug, formatDate } from '../data/blogPosts'
import { SITE } from '../config/site'

const BlogPostPage = () => {
  const { slug } = useParams()
  
  useEffect(() => {
    window.scrollTo(0, 0);
    AOS.refresh();
  }, [slug])

  const post = blogBySlug[slug]
  if (!post) return <NotFound />
  const articleLd = {
    '@context': 'https://schema.org', '@type': 'Article', headline: post.title, description: post.excerpt,
    image: post.image, datePublished: post.date, dateModified: post.date,
    author: { '@type': 'Organization', name: SITE.name }, publisher: { '@type': 'Organization', name: SITE.name, logo: { '@type': 'ImageObject', url: `${SITE.url}/favicon.png` } },
    mainEntityOfPage: `${SITE.url}${post.path}`,
  }

  return (
    <div className="blog-post-page">
      <SEO
        title={post.title}
        description={post.excerpt}
        path={post.path}
        image={post.image}
        type="article"
        jsonLd={[articleLd, breadcrumbLd([{name:'Home',path:'/'},{name:'Blog',path:'/blog'},{name:post.title,path:post.path}])]}
      />
      <article className="post-container">
        
        <header className="blog-post-header" data-aos="fade-up">
          <div style={{textAlign: 'left', maxWidth: '800px', margin: '0 auto'}}>
            <Link to="/blog" className="back-to-blog"><FaArrowLeft /> Back to Blog</Link>
          </div>
          <span className="post-category-badge">{post.category}</span>
          <h1 className="post-main-title">{post.title}</h1>
          <div className="post-meta-info">
            <div className="post-meta-item"><FaCalendarAlt /> {formatDate(post.date)}</div>
            <div className="post-meta-item"><FaUserEdit /> {post.author}</div>
          </div>
        </header>

        <div className="post-featured-image" data-aos="fade-up" data-aos-delay="100">
          <img src={post.image} alt={post.title} loading="lazy" decoding="async" />
        </div>

        <div 
          className="post-content" 
          data-aos="fade-up" 
          data-aos-delay="200"
          dangerouslySetInnerHTML={{ __html: post.content }} 
        />
        
      </article>
    </div>
  )
}

export default BlogPostPage
