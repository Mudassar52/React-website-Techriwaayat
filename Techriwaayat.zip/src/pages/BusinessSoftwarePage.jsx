import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  FaCashRegister, FaWarehouse, FaStore, FaWrench, FaClinicMedical,
  FaUtensils, FaTshirt, FaPills, FaCheckCircle, FaBarcode, FaChartLine,
  FaUsers, FaCloud, FaShieldAlt, FaBolt, FaHeadset, FaMinus, FaPlus,
  FaComments, FaMobileAlt, FaPrint, FaBoxes, FaFileInvoiceDollar, FaClipboardCheck,
  FaCheck
} from 'react-icons/fa'
import { SiReact, SiMysql, SiElectron, SiFirebase } from 'react-icons/si'
import './ServicesShared.css'
import './BusinessSoftwarePage.css'
import '../components/Pricing.css'
import AOS from 'aos'
import SEO from '../components/SEO'

const BusinessSoftwarePage = () => {
  const [activeFaq, setActiveFaq] = useState(null)

  useEffect(() => {
    window.scrollTo(0, 0);
    AOS.refresh();
  }, [])

  const toggleFaq = (index) => {
    setActiveFaq(activeFaq === index ? null : index)
  }

  const businessSoftwareJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    serviceType: 'Business Management Software Development',
    name: 'Business & POS Software Development',
    provider: {
      '@type': 'Organization',
      name: 'Tech Riwaayat',
      url: 'https://techriwaayat.com',
    },
    areaServed: { '@type': 'Country', name: 'Pakistan' },
    description: 'Custom POS, wholesale, retail, spare parts, clinic, restaurant, clothing shop and pharmacy management software.',
  }

  const industries = [
    { icon: FaCashRegister, title: 'POS Systems', desc: 'Fast, reliable Point of Sale software for shops, counters, and checkout points with receipt printing and cash management.', color: '#00d97e' },
    { icon: FaWarehouse, title: 'Wholesale & Distribution', desc: 'Bulk order management, dealer ledgers, multi-warehouse stock tracking, and price-tier management for distributors.', color: '#3b82f6' },
    { icon: FaStore, title: 'Retail Management', desc: 'Complete retail suite with billing, discounts, loyalty points, and daily sales reporting for single or multi-branch shops.', color: '#f59e0b' },
    { icon: FaWrench, title: 'Spare Parts & Auto Shops', desc: 'Part-number based inventory, vehicle compatibility search, and supplier tracking built for auto & hardware stores.', color: '#8b5cf6' },
    { icon: FaClinicMedical, title: 'Clinics & Healthcare', desc: 'Patient records, appointment scheduling, prescriptions, and billing software for clinics and small hospitals.', color: '#ef4444' },
    { icon: FaUtensils, title: 'Restaurants & Cafes', desc: 'Table & order management, kitchen display, delivery integration, and menu-wise sales insights.', color: '#f97316' },
    { icon: FaTshirt, title: 'Clothing & Fashion Retail', desc: 'Size, color & variant-based inventory, seasonal collections, and barcode billing for garment stores.', color: '#ec4899' },
    { icon: FaPills, title: 'Pharmacy Management', desc: 'Batch & expiry tracking, medicine stock alerts, supplier purchase orders, and fast prescription-based billing.', color: '#14b8a6' },
  ]

  const pricingPlans = [
    {
      id: 1,
      name: 'Starter Package',
      price: 'Rs. 120,000',
      period: '/ one-time',
      desc: 'Perfect for a single shop, clinic, or counter getting started with digital billing.',
      features: [
        'Single Branch / Single Counter',
        'POS Billing & Barcode Scanning',
        'Inventory & Stock Management',
        'Customer & Supplier Ledger',
        'Basic Sales Reports',
        'Receipt Printer Setup',
        'Staff Training Included',
        '1 Month Free Support'
      ],
      highlighted: false
    },
    {
      id: 2,
      name: 'Advanced Package',
      price: 'Rs. 150,000',
      period: '/ one-time',
      desc: 'Our most complete package — built for growing businesses with more than one counter.',
      features: [
        'Everything in Starter Package',
        'Multi-Branch / Multi-Counter Support',
        'Advanced Reports & Analytics',
        'Role-Based Staff Access',
        'Custom Invoice Formats',
        'Cloud Backup & Sync',
        'Priority Delivery',
        '3 Months Free Support'
      ],
      highlighted: true
    },
    {
      id: 3,
      name: 'Enterprise Package',
      price: 'Rs. 250,000',
      period: '/ one-time',
      desc: 'For large multi-branch businesses that need a fully custom, end-to-end system.',
      features: [
        'Everything in Advanced Package',
        'Unlimited Branches & Counters',
        'Custom Modules Built to Order',
        'Advanced Business Analytics & Insights',
        'Third-Party & API Integrations',
        'Dedicated Account Manager',
        'On-Site Staff Training',
        '6 Months Free Support'
      ],
      highlighted: false
    }
  ]

  const rentalPlans = [
    {
      id: 'monthly',
      name: 'Monthly Rental',
      price: 'Rs. 4,000 - 5,000',
      period: '/ month, per software',
      desc: 'Not ready to buy? Rent the software you need on a simple monthly basis — no big upfront cost.',
      features: [
        'Full Software Usage License',
        'Any Software Type (POS, Retail, Clinic, etc.)',
        'Regular Updates & Bug Fixes',
        'Basic Technical Support',
        'Cancel or Upgrade Anytime',
        'Setup & Staff Training Included'
      ],
      highlighted: false
    },
    {
      id: 'yearly',
      name: 'Yearly Rental',
      price: 'Rs. 50,000',
      period: '/ year, per software',
      desc: 'Our best-value rental — save compared to paying monthly, with the same full software access.',
      features: [
        'Everything in Monthly Rental',
        'Better Value than 12 Monthly Payments',
        'Priority Technical Support',
        'Free Minor Feature Updates',
        'Cancel or Upgrade Anytime',
        'Setup & Staff Training Included'
      ],
      highlighted: true
    }
  ]

  const faqs = [
    { q: "Can this software be customized for my specific business type?", a: "Yes, absolutely. We don't sell one rigid template — every POS, retail, wholesale, clinic, restaurant, clothing, or pharmacy system we build is customized around how your business actually operates, including your product categories, invoice format, and reporting needs." },
    { q: "Will the software work without internet, or offline?", a: "Yes. We build both offline desktop POS systems (for shops with unreliable internet) and cloud-based systems that sync across multiple branches in real time — you choose what fits your setup." },
    { q: "Do you provide multi-branch and multi-user support?", a: "Yes. Our business software supports multiple branches, multiple counters, and role-based staff access (cashier, manager, admin) so you can monitor every location from one dashboard." },
    { q: "What about training and after-sales support?", a: "Every project includes staff training so your team can use the system confidently from day one, plus ongoing technical support and updates as your business grows." },
    { q: "How long does it take to build a business software solution?", a: "A standard single-branch POS or retail system typically takes 3-5 weeks. Larger systems like multi-branch wholesale, pharmacy, or clinic management software with custom reporting can take 6-10 weeks depending on scope." },
  ]

  return (
    <div className="service-page">
      <SEO
        title="POS & Business Software Development in Pakistan"
        description="POS and business software in Pakistan for retail, wholesale, restaurants, clinics and pharmacies. Custom-built around your exact business workflow."
        path="/services/business-software"
        jsonLd={businessSoftwareJsonLd}
      />
      {/* 1. Hero Section */}
      <section className="service-hero">
        <div className="service-hero-container" data-aos="fade-up">
          <span className="service-badge"><FaCashRegister className="badge-icon" /> BUSINESS MANAGEMENT SOFTWARE</span>
          <h1 className="service-main-title">Smart Software Built for <span className="highlight">Your Kind of Business</span></h1>
          <p className="service-hero-description">From POS counters to pharmacy shelves, we design and build reliable business management software for shops, wholesalers, clinics, restaurants, clothing stores, and spare part dealers — made to fit exactly how you work.</p>
          <div className="hero-cta-buttons">
            <Link to="/contact" className="btn btn-primary cta-btn">Get a Free Demo</Link>
          </div>
        </div>
      </section>

      {/* 2. Overview */}
      <section className="service-overview section-padding" data-aos="fade-up">
        <div className="container">
          <div className="overview-content text-center">
            <h2 className="text-center">One Partner for Every <span className="highlight">Industry.</span></h2>
            <p className="mt-4 text-center">Every business runs differently — a pharmacy tracks expiry dates, a wholesaler tracks dealer credit, a restaurant tracks tables and orders. Instead of forcing your business into generic software, we build systems around your real day-to-day operations, so billing, inventory, and reporting finally work the way you do.</p>
          </div>
        </div>
      </section>

      {/* 2b. Client Requirement Banner */}
      <section className="requirement-banner">
        <div className="container">
          <div className="requirement-box" data-aos="fade-up">
            <div className="requirement-icon"><FaClipboardCheck /></div>
            <div>
              <h3>Built Around Your Exact Requirements</h3>
              <p>We don't hand you a fixed template. Every screen, report, invoice format, and workflow is designed and developed according to how your specific business runs — your products, your branches, your staff structure, your rules.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Industries We Serve */}
      <section className="industries-section section-padding bg-light">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center">Industries We Build Software For</h2>
            <p className="section-subtitle text-center">Purpose-built solutions across retail and service businesses.</p>
          </div>
          <div className="industry-grid">
            {industries.map((item, index) => {
              const Icon = item.icon
              return (
                <div className="industry-card" key={index} data-aos="fade-up" data-aos-delay={index * 80}>
                  <div className="industry-icon-wrap" style={{ background: `${item.color}1a`, color: item.color }}>
                    <Icon />
                  </div>
                  <h3>{item.title}</h3>
                  <p>{item.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* 4. Why Choose Us / Mockup */}
      <section className="why-choose-us section-padding">
        <div className="container">
          <div className="split-layout">
            <div className="split-text" data-aos="fade-right">
              <h2>One Dashboard. Total Control.</h2>
              <p>Whether it's a single shop counter or multiple branches across the city, you get one clean dashboard to manage sales, stock, staff, and customers — built to be simple enough for daily staff to use, and powerful enough for owners to trust.</p>
              <ul className="custom-list mt-4">
                <li><FaCheckCircle className="list-icon" /> <strong>Real-Time Inventory:</strong> Live stock levels across every branch and counter.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Fast Billing:</strong> Barcode scanning and one-tap checkout to keep queues moving.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Role-Based Access:</strong> Owners see everything, staff only see what they need.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Detailed Reports:</strong> Daily, weekly, and monthly profit & sales reports on demand.</li>
              </ul>
            </div>
            <div className="split-image-placeholder" style={{background: 'transparent', padding: 0}} data-aos="fade-left">
              <img
                src="/images/business-software/dashboard.jpg"
                alt="Business Management Dashboard"
                className="wide-showcase-img"
                loading="lazy"
                width="1200"
                height="520"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 4b. Reports Section */}
      <section className="reports-section section-padding bg-light">
        <div className="container">
          <div className="split-layout" style={{alignItems: 'center', flexDirection: 'row-reverse'}}>
            <div className="split-text" data-aos="fade-left">
              <h2>Reports That Actually Help You Decide</h2>
              <p>No more guessing how the business is doing. Get clear, easy-to-read reports built exactly around what you need to track — whether that's daily counter sales, monthly profit, or which products are moving fastest.</p>
              <ul className="custom-list mt-4">
                <li><FaCheckCircle className="list-icon" /> <strong>Daily & Monthly Sales Reports:</strong> Know exactly what sold, where, and when.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Profit & Loss Summary:</strong> Real-time view of margins across products and branches.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Stock & Expiry Reports:</strong> Catch low stock or near-expiry items before they become a problem.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Staff Performance Reports:</strong> See which counter or staff member is performing best.</li>
              </ul>
            </div>
            <div className="split-image-placeholder" style={{background: 'transparent', padding: 0}} data-aos="fade-right">
              <img
                src="/images/business-software/reports.jpg"
                alt="Business Sales & Profit Reports"
                className="wide-showcase-img"
                loading="lazy"
                width="1200"
                height="520"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 4c. Invoice Section */}
      <section className="invoice-section section-padding">
        <div className="container">
          <div className="split-layout" style={{alignItems: 'center'}}>
            <div className="split-text" data-aos="fade-right">
              <h2>Professional Invoices, Every Single Time</h2>
              <p>Generate clean, accurate invoices in seconds — formatted exactly the way your business needs them, whether it's a retail receipt, a wholesale bill, a clinic slip, or a pharmacy prescription invoice.</p>
              <ul className="custom-list mt-4">
                <li><FaCheckCircle className="list-icon" /> <strong>Custom Invoice Formats:</strong> Your logo, terms, and layout — built to your requirement.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Auto Tax & Discount Calculation:</strong> No manual math, no billing mistakes.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Print or Share Digitally:</strong> Thermal print, PDF, or WhatsApp share, your choice.</li>
                <li><FaCheckCircle className="list-icon" /> <strong>Customer & Supplier Ledgers:</strong> Every invoice automatically updates the right ledger.</li>
              </ul>
            </div>
            <div className="split-image-placeholder" style={{background: 'transparent', padding: 0}} data-aos="fade-left">
              <img
                src="/images/business-software/invoice.jpg"
                alt="Invoicing and Billing"
                className="wide-showcase-img"
                loading="lazy"
                width="1200"
                height="520"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 5. Key Features */}
      <section className="features-section section-padding bg-light">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center">Core Features, Built In</h2>
            <p className="section-subtitle text-center">Everything a modern shop, wholesaler, clinic, or restaurant needs, out of the box.</p>
          </div>
          <div className="benefits-list-grid">
            <div className="benefit-item" data-aos="fade-right">
              <FaBarcode className="benefit-icon" />
              <div>
                <h4>Barcode Billing</h4>
                <p>Scan-and-go checkout with barcode/QR support for fast, error-free billing.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaBoxes className="benefit-icon" />
              <div>
                <h4>Inventory & Stock Alerts</h4>
                <p>Automatic low-stock and expiry alerts so you never run out or oversell.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-right">
              <FaFileInvoiceDollar className="benefit-icon" />
              <div>
                <h4>Invoicing & Ledgers</h4>
                <p>Customer and supplier ledgers, credit tracking, and printable invoices.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaChartLine className="benefit-icon" />
              <div>
                <h4>Sales & Profit Reports</h4>
                <p>Daily, weekly, and monthly reports to track profit, best-sellers, and trends.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-right">
              <FaUsers className="benefit-icon" />
              <div>
                <h4>Staff & Role Management</h4>
                <p>Give cashiers, managers, and admins exactly the access they need — nothing more.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaPrint className="benefit-icon" />
              <div>
                <h4>Receipt Printer Support</h4>
                <p>Works with thermal receipt printers and standard printers out of the box.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-right">
              <FaCloud className="benefit-icon" />
              <div>
                <h4>Multi-Branch Sync</h4>
                <p>Cloud sync across branches so owners see the full picture from anywhere.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaMobileAlt className="benefit-icon" />
              <div>
                <h4>Works On Any Device</h4>
                <p>Desktop, tablet, or mobile — billing counters that fit your existing hardware.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Development Process */}
      <section className="dev-process section-padding bg-dark">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center text-white">How We Build Your System</h2>
            <p className="section-subtitle text-center text-light-gray">A clear, guided process from first meeting to go-live.</p>
          </div>
          <div className="process-steps-grid">
            <div className="process-step-card" data-aos="fade-up" data-aos-delay="100">
              <div className="step-number-large">01</div>
              <h3>Understand Your Business</h3>
              <p>We study your daily workflow — billing, stock, staff — before writing a single line of code.</p>
            </div>
            <div className="process-step-card" data-aos="fade-up" data-aos-delay="200">
              <div className="step-number-large">02</div>
              <h3>Design the System</h3>
              <p>Simple, clean screens designed for your staff, not just for tech-savvy users.</p>
            </div>
            <div className="process-step-card" data-aos="fade-up" data-aos-delay="300">
              <div className="step-number-large">03</div>
              <h3>Build & Configure</h3>
              <p>We develop the software and configure it with your products, categories, and pricing.</p>
            </div>
            <div className="process-step-card" data-aos="fade-up" data-aos-delay="400">
              <div className="step-number-large">04</div>
              <h3>Test With Real Data</h3>
              <p>We test billing, printing, and reports using your actual products before go-live.</p>
            </div>
            <div className="process-step-card" data-aos="fade-up" data-aos-delay="500">
              <div className="step-number-large">05</div>
              <h3>Launch & Train Staff</h3>
              <p>We install, train your team hands-on, and stay on for ongoing support.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Technologies */}
      <section className="technologies section-padding">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center">Reliable Technology Behind It</h2>
            <p className="section-subtitle text-center">Stable, proven tools chosen for everyday business use, not just demos.</p>
          </div>
          <div className="tech-grid" data-aos="zoom-in">
            <div className="tech-item"><SiReact className="tech-icon react"/><span>React</span></div>
            <div className="tech-item"><SiElectron className="tech-icon" style={{color:'#47848f'}}/><span>Electron (Desktop)</span></div>
            <div className="tech-item"><SiMysql className="tech-icon" style={{color:'#00758f'}}/><span>MySQL</span></div>
            <div className="tech-item"><SiFirebase className="tech-icon" style={{color:'#ffca28'}}/><span>Firebase</span></div>
            <div className="tech-item"><FaCloud className="tech-icon" style={{color:'#00d97e'}}/><span>Cloud Sync</span></div>
            <div className="tech-item"><FaShieldAlt className="tech-icon" style={{color:'#00d97e'}}/><span>Secure Backups</span></div>
          </div>
        </div>
      </section>

      {/* 8. Why Businesses Trust Us */}
      <section className="benefits section-padding bg-light">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center">Why Businesses Trust Us</h2>
          </div>
          <div className="benefits-list-grid">
            <div className="benefit-item" data-aos="fade-right">
              <FaBolt className="benefit-icon" />
              <div>
                <h4>Fast & Lightweight</h4>
                <p>Built to run smoothly even on basic shop computers, with no lag at checkout.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaShieldAlt className="benefit-icon" />
              <div>
                <h4>Secure by Design</h4>
                <p>Daily backups and role-based access keep your business data safe.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-right">
              <FaHeadset className="benefit-icon" />
              <div>
                <h4>Real Support</h4>
                <p>Direct access to our team for updates, fixes, and new features as you grow.</p>
              </div>
            </div>
            <div className="benefit-item" data-aos="fade-left">
              <FaCheckCircle className="benefit-icon" />
              <div>
                <h4>Built Around You</h4>
                <p>No forced templates — the software adapts to your business, not the other way around.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8b. Pricing */}
      <section id="pricing" className="pricing-section">
        <div className="pricing-container">
          <div className="pricing-header" data-aos="fade-up">
            <span className="pricing-label">PRICING PLANS</span>
            <h2 className="pricing-title">
              Simple, Upfront <span className="highlight">Pricing</span>
            </h2>
            <p className="pricing-desc">
              Choose the package that fits your business. Every plan is still built around your exact requirement — not a fixed template.
            </p>
          </div>

          <div className="pricing-grid" style={{maxWidth: '1100px', margin: '0 auto'}}>
            {pricingPlans.map((plan, index) => (
              <div
                className={`pricing-card ${plan.highlighted ? 'pricing-card-highlight' : ''}`}
                key={plan.id}
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                {plan.highlighted && <span className="pricing-badge">Most Popular</span>}

                <h3 className="pricing-plan-name">{plan.name}</h3>
                <p className="pricing-plan-desc">{plan.desc}</p>

                <div className="pricing-price-row">
                  <span className="pricing-price">{plan.price}</span>
                  <span className="pricing-period">{plan.period}</span>
                </div>

                <ul className="pricing-features">
                  {plan.features.map((feature, i) => (
                    <li key={i}>
                      <FaCheck className="pricing-check" /> {feature}
                    </li>
                  ))}
                </ul>

                <Link
                  to="/contact"
                  className={`pricing-btn ${plan.highlighted ? 'pricing-btn-highlight' : ''}`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>

          <div className="pricing-custom-note" data-aos="fade-up">
            <p>Need something more advanced — extra branches, custom modules, or deeper integrations? <Link to="/contact">Contact us</Link> and we'll work out a custom quote for your exact requirement.</p>
          </div>
        </div>
      </section>

      {/* 8c. Rental Plans (Monthly / Yearly) */}
      <section id="rental-plans" className="pricing-section bg-light">
        <div className="pricing-container">
          <div className="pricing-header" data-aos="fade-up">
            <span className="pricing-label">RENT INSTEAD OF BUY</span>
            <h2 className="pricing-title">
              Prefer to <span className="highlight">Rent the Software?</span>
            </h2>
            <p className="pricing-desc">
              Don't want to pay the full price upfront? Rent any of our business software on a monthly or yearly basis — same full features, lower entry cost.
            </p>
          </div>

          <div className="pricing-grid" style={{ maxWidth: '820px', margin: '0 auto' }}>
            {rentalPlans.map((plan, index) => (
              <div
                className={`pricing-card ${plan.highlighted ? 'pricing-card-highlight' : ''}`}
                key={plan.id}
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                {plan.highlighted && <span className="pricing-badge">Best Value</span>}

                <h3 className="pricing-plan-name">{plan.name}</h3>
                <p className="pricing-plan-desc">{plan.desc}</p>

                <div className="pricing-price-row">
                  <span className="pricing-price">{plan.price}</span>
                  <span className="pricing-period">{plan.period}</span>
                </div>

                <ul className="pricing-features">
                  {plan.features.map((feature, i) => (
                    <li key={i}>
                      <FaCheck className="pricing-check" /> {feature}
                    </li>
                  ))}
                </ul>

                <Link
                  to="/contact"
                  className={`pricing-btn ${plan.highlighted ? 'pricing-btn-highlight' : ''}`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>

          <div className="pricing-custom-note" data-aos="fade-up">
            <p>Rental price depends on the specific software you need. <Link to="/contact">Contact us</Link> and we'll confirm the exact monthly or yearly rate for your business.</p>
          </div>
        </div>
      </section>

      {/* 9. FAQ */}
      <section className="service-faq section-padding">
        <div className="container">
          <div className="section-header text-center" data-aos="fade-up">
            <h2 className="text-center">Frequently Asked Questions</h2>
          </div>
          <div className="faq-container">
            {faqs.map((faq, index) => (
              <div
                className={`faq-item ${activeFaq === index ? 'active' : ''}`}
                key={index}
                onClick={() => toggleFaq(index)}
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="faq-question">
                  <h3>{faq.q}</h3>
                  <span className="faq-toggle-icon">
                    {activeFaq === index ? <FaMinus /> : <FaPlus />}
                  </span>
                </div>
                <div className="faq-answer" style={{ padding: activeFaq === index ? '0 20px 20px' : '0 20px', maxHeight: activeFaq === index ? '260px' : '0' }}>
                  <p>{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. CTA */}
      <section className="service-bottom-cta">
        <div className="container text-center" data-aos="zoom-in">
          <div className="service-cta-box">
            <h2 className="text-center text-white">Ready to Digitize Your Business?</h2>
            <p className="text-light-gray mt-3 text-center">Tell us about your shop, clinic, or restaurant — we'll show you exactly how it works before you commit.</p>
            <div className="cta-buttons mt-4 text-center">
              <Link to="/contact" className="btn btn-primary cta-btn">Book a Free Demo <FaComments className="ms-2"/></Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  )
}

export default BusinessSoftwarePage
