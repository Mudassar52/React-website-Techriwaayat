import React, { useEffect } from 'react'
import SEO from '../components/SEO'
import { SITE } from '../config/site'
import './LandingPage.css'

const CONTENT = {
  privacy: { title: 'Privacy Policy', path: '/privacy-policy', body: [
    ['Information we collect', `When you contact us through our forms, email or WhatsApp we collect the details you provide, such as your name, email, phone number and project requirements.`],
    ['How we use it', 'We use this information to reply to your enquiry, prepare quotes, deliver services and improve our website. We do not sell your personal data.'],
    ['Analytics & cookies', 'We may use analytics tools to understand how visitors use the site. You can control cookies in your browser settings.'],
    ['Data retention & your rights', `You may ask us to update or delete your data at any time by emailing ${SITE.email}.`],
    ['Contact', `${SITE.name}, ${SITE.city}, ${SITE.region}, Pakistan. Email: ${SITE.email}.`] ] },
  terms: { title: 'Terms of Service', path: '/terms-of-service', body: [
    ['Use of this website', 'The content on this website is for general information about our services. You agree not to misuse the site or attempt to disrupt it.'],
    ['Services & quotes', 'Project scope, timeline, price and payment terms are agreed in a written proposal or contract before work starts.'],
    ['Intellectual property', 'Website content and branding belong to Tech Riwaayat. Ownership of project deliverables is defined in each project agreement.'],
    ['Limitation of liability', 'We make reasonable efforts to keep information accurate but provide the website as is, without warranties.'],
    ['Contact', `Questions about these terms: ${SITE.email}.`] ] },
}

const LegalPage = ({ type }) => {
  const c = CONTENT[type]
  useEffect(() => { window.scrollTo(0, 0) }, [type])
  return (
    <div className="lp">
      <SEO title={c.title} description={`${c.title} of ${SITE.name}.`} path={c.path} />
      <header className="lp-hero" style={{ paddingBottom: 30 }}><h1>{c.title}</h1></header>
      <div className="lp-wrap lp-legal" style={{ paddingBottom: 60 }}>
        {c.body.map(([h, t]) => <div key={h}><h2>{h}</h2><p>{t}</p></div>)}
      </div>
    </div>
  )
}
export default LegalPage
