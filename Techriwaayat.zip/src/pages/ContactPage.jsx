import React, { useEffect, useState } from 'react'
import { FaPhoneAlt, FaEnvelope, FaMapMarkerAlt, FaPaperPlane } from 'react-icons/fa'
import './ContactPage.css'
import AOS from 'aos'
import SEO from '../components/SEO'
import { submitLead } from '../utils/submitLead'
import { waLink } from '../config/site'

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  })

  useEffect(() => {
    window.scrollTo(0, 0);
    AOS.refresh();
  }, [])

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const [status, setStatus] = useState({ type: '', message: '' })
  const [sending, setSending] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSending(true); setStatus({ type: '', message: '' })
    const r = await submitLead(formData)
    setSending(false)
    if (r.ok) { setStatus({ type: 'success', message: 'Thank you! We received your message and will reply shortly.' }); setFormData({ name: '', email: '', phone: '', service: '', message: '' }) }
    else setStatus({ type: 'error', message: r.message })
  }

  return (
    <div className="contact-page">
      <SEO
        title="Contact a Software House in Pakistan: Get a Free Quote"
        description="Contact Tech Riwaayat by form, WhatsApp or phone for custom software, POS, web development, mobile apps or AI automation. Free quote."
        path="/contact"
      />
      {/* Hero Section */}
      <section className="contact-hero" data-aos="fade-up">
        <div className="contact-hero-container">
          <span className="contact-badge">GET IN TOUCH</span>
          <h1 className="contact-main-title">Let's <span className="highlight">Talk</span></h1>
          <p className="contact-hero-desc">
            Ready to transform your ideas into reality? Schedule a call with our experts today. We are here to answer your questions and discuss how we can help your business thrive in the digital age.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="cp-content">
        <div className="cp-container">
          
          {/* Left Column: Contact Info */}
          <div className="cp-info-col" data-aos="fade-right">
            <h2>Contact Information</h2>
            <p className="cp-info-subtext">Fill out the form and our team will get back to you within 24 hours.</p>
            
            <div className="cp-info-cards">
              <div className="cp-info-card">
                <div className="cp-info-icon-wrapper">
                  <FaEnvelope />
                </div>
                <div className="cp-info-details">
                  <h3>Email Us</h3>
                  <p><a href="mailto:TeamTechRiwaayat@gmail.com" style={{color:"inherit"}}>TeamTechRiwaayat@gmail.com</a></p>
                </div>
              </div>
              
              <div className="cp-info-card">
                <div className="cp-info-icon-wrapper">
                  <FaPhoneAlt />
                </div>
                <div className="cp-info-details">
                  <h3>Call Us</h3>
                  <p><a href="tel:+923263555252" style={{color:"inherit"}}>+92 3263 555252</a> · <a href={waLink()} target="_blank" rel="noopener noreferrer" style={{color:"#0b7a4b"}}>WhatsApp</a></p>
                </div>
              </div>
              
              <div className="cp-info-card">
                <div className="cp-info-icon-wrapper">
                  <FaMapMarkerAlt />
                </div>
                <div className="cp-info-details">
                  <h3>Visit Us</h3>
                  <p>Lahore, Punjab, Pakistan</p>
                </div>
              </div>
            </div>

            <div className="cp-working-hours">
              <h3>Working Hours</h3>
              <p>Monday - Friday: 9:00 AM - 6:00 PM (PKT)</p>
              <p>Available 24/7 for urgent technical support.</p>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="cp-form-col" data-aos="fade-left">
            <div className="cp-form-wrapper">
              <h2>Schedule a Call</h2>
              <form onSubmit={handleSubmit} className="cp-contact-form">
                
                <div className="cp-form-group">
                  <label htmlFor="name">Full Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    placeholder="John Doe" 
                    value={formData.name}
                    onChange={handleChange}
                    required 
                  />
                </div>
                
                <div className="cp-form-row">
                  <div className="cp-form-group">
                    <label htmlFor="email">Email Address</label>
                    <input 
                      type="email" 
                      id="email" 
                      name="email" 
                      placeholder="john@company.com" 
                      value={formData.email}
                      onChange={handleChange}
                      required 
                    />
                  </div>
                  
                  <div className="cp-form-group">
                    <label htmlFor="phone">Phone Number</label>
                    <input 
                      type="tel" 
                      id="phone" 
                      name="phone" 
                      placeholder="+1 (555) 000-0000" 
                      value={formData.phone}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                
                <div className="cp-form-group">
                  <label htmlFor="service">Service Interested In</label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    required
                    className="cp-form-select"
                  >
                    <option value="" disabled>Select a Service</option>
                    <option value="Web Design & Development">Web Design & Development</option>
                    <option value="Mobile App Development">Mobile App Development</option>
                    <option value="E-Commerce Development">E-Commerce Development</option>
                    <option value="AI & Automation">AI & Automation</option>
                    <option value="Custom Software">Custom Software</option>
                    <option value="SEO Optimization">SEO Optimization</option>
                    <option value="WordPress & Plugins">WordPress & Plugins</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="cp-form-group">
                  <label htmlFor="message">How can we help you?</label>
                  <textarea 
                    id="message" 
                    name="message" 
                    rows="5" 
                    placeholder="Tell us about your project, goals, and timeline..." 
                    value={formData.message}
                    onChange={handleChange}
                    required
                  ></textarea>
                </div>
                
                <input type="text" name="website" tabIndex="-1" autoComplete="off" style={{position:'absolute',left:'-9999px'}} aria-hidden="true" onChange={handleChange} />
                <button type="submit" className="cp-submit-btn" disabled={sending}>
                  {sending ? 'Sending...' : 'Send Message'} <FaPaperPlane className="cp-btn-icon" />
                </button>
                {status.message && <p role="status" style={{marginTop:12,fontWeight:600,color:status.type==='success'?'#0b7a4b':'#c0392b'}}>{status.message}</p>}
              </form>
            </div>
          </div>

        </div>
      </section>
    </div>
  )
}

export default ContactPage
