import React, { useEffect } from 'react'
import SEO, { breadcrumbLd } from '../components/SEO'
import SolutionsGrid from '../components/SolutionsGrid'
import './LandingPage.css'

const SolutionsPage = () => {
  useEffect(() => { window.scrollTo(0, 0) }, [])
  return (
    <div className="lp">
      <SEO title="Software Solutions in Pakistan: POS, ERP, Web, Apps | Tech Riwaayat" fullTitle
        description="Explore Tech Riwaayat's software solutions in Pakistan: custom software, POS, inventory, ERP, e-commerce, React, mobile apps and AI automation."
        path="/solutions" jsonLd={breadcrumbLd([{ name: 'Home', path: '/' }, { name: 'Solutions', path: '/solutions' }])} />
      <header className="lp-hero">
        <span className="lp-badge">SOLUTIONS</span>
        <h1>Software Solutions for Pakistani Businesses</h1>
        <p className="lp-lead">From POS and inventory to ERP, websites, apps and automation, pick the solution that matches your business.</p>
      </header>
      <SolutionsGrid title="All Solutions" />
    </div>
  )
}
export default SolutionsPage
