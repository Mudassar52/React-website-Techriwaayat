import React, { useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { FaWhatsapp, FaArrowRight } from 'react-icons/fa'
import SEO, { breadcrumbLd, faqLd } from '../components/SEO'
import NotFound from './NotFound'
import { seoPagesBySlug } from '../data/seoPages'
import { SITE, waLink } from '../config/site'
import './LandingPage.css'

const PROCESS = [['Discuss','A short call or WhatsApp chat to understand your business and goals.'],['Scope & quote','A written scope, timeline and price before work begins.'],['Build & demo','Regular demos so you see real progress and can steer early.'],['Launch & support','Deployment, training and ongoing maintenance.']]

const SeoLandingPage = ({ slug: slugProp }) => {
  const params = useParams()
  const slug = slugProp || params.slug
  const page = seoPagesBySlug[slug]
  useEffect(() => { window.scrollTo(0, 0) }, [slug])
  if (!page) return <NotFound />
  const path = `/${page.slug}`
  const short = page.h1
  const serviceLd = {
    '@context': 'https://schema.org', '@type': 'Service', name: short, serviceType: short,
    provider: { '@type': 'ProfessionalService', name: SITE.name, url: SITE.url },
    areaServed: { '@type': 'Country', name: 'Pakistan' }, description: page.description,
  }
  return (
    <div className="lp">
      <SEO title={page.title} fullTitle description={page.description} path={path}
        jsonLd={[serviceLd, faqLd(page.faqs), breadcrumbLd([{ name: 'Home', path: '/' }, { name: 'Solutions', path: '/solutions' }, { name: short, path }])]} />
      <nav className="lp-crumbs" aria-label="Breadcrumb"><Link to="/">Home</Link> / <Link to="/solutions">Solutions</Link> / {short}</nav>
      <header className="lp-hero">
        <span className="lp-badge">{page.badge}</span>
        <h1>{page.h1}</h1>
        <p className="lp-lead">{page.intro[0]}</p>
        <div className="lp-cta">
          <Link to="/contact" className="lp-btn primary">Get a Free Quote <FaArrowRight /></Link>
          <a href={waLink(`Hi Tech Riwaayat, I am interested in: ${page.h1}`)} className="lp-btn wa" target="_blank" rel="noopener noreferrer"><FaWhatsapp /> WhatsApp Us</a>
        </div>
      </header>

      <section className="lp-sec"><div className="lp-wrap">
        <h2>{page.badge.charAt(0) + page.badge.slice(1).toLowerCase()} by Tech Riwaayat</h2>
        <p>{page.intro[1]}</p>
        <p>Our team works with clients in {SITE.cities.join(', ')} and across Pakistan, and also supports international clients remotely.</p>
      </div></section>

      <section className="lp-sec alt"><div className="lp-wrap">
        <h2>What You Get</h2>
        <div className="lp-grid">{page.features.map(([t, d]) => <div className="lp-card" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div>
      </div></section>

      <section className="lp-sec"><div className="lp-wrap">
        <h2>Who This Is For</h2>
        <div className="lp-tags">{page.audience.map(a => <span className="lp-tag" key={a}>{a}</span>)}</div>
      </div></section>

      <section className="lp-sec alt"><div className="lp-wrap">
        <h2>How We Work</h2>
        <div className="lp-steps">{PROCESS.map(([t, d]) => <div className="lp-step" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div>
      </div></section>

      <section className="lp-sec"><div className="lp-wrap lp-faq">
        <h2>Frequently Asked Questions</h2>
        {page.faqs.map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}
      </div></section>

      <section className="lp-sec alt"><div className="lp-wrap">
        <h2>Related Solutions</h2>
        <div className="lp-grid">
          {page.related.map(r => seoPagesBySlug[r]).filter(Boolean).map(p => (
            <Link to={`/${p.slug}`} className="lp-card" key={p.slug}><h3>{p.h1}</h3><p>{p.features[0][1]}</p></Link>
          ))}
        </div>
        <p style={{ marginTop: 22 }}>Also see our <Link to="/blog">software and business guides</Link> and <Link to="/services/business-software">business software services</Link>.</p>
      </div></section>

      <section className="lp-final">
        <h2>Tell Us What You Need</h2>
        <p>Share your requirement and get a clear, written quote. No pressure, no jargon.</p>
        <div className="lp-cta">
          <Link to="/contact" className="lp-btn primary">Request a Quote</Link>
          <a href={`tel:${SITE.phoneE164}`} className="lp-btn ghost">Call {SITE.phoneDisplay}</a>
        </div>
      </section>
    </div>
  )
}
export default SeoLandingPage
