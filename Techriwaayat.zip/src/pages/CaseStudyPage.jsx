import React, { useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import SEO, { breadcrumbLd } from '../components/SEO'
import NotFound from './NotFound'
import { caseStudyBySlug } from '../data/caseStudies'
import './LandingPage.css'

const List = ({ items }) => <div className="lp-tags">{items.map(i => <span className="lp-tag" key={i}>{i}</span>)}</div>

const CaseStudyPage = () => {
  const { slug } = useParams()
  useEffect(() => { window.scrollTo(0, 0) }, [slug])
  const c = caseStudyBySlug[slug]
  if (!c) return <NotFound />
  const path = `/portfolio/${c.slug}`
  return (
    <div className="lp">
      <SEO title={`${c.title} | Case Study`} fullTitle description={c.summary} path={path} image={c.image ? `https://techriwaayat.com${c.image}` : undefined}
        jsonLd={breadcrumbLd([{ name: 'Home', path: '/' }, { name: 'Portfolio', path: '/portfolio' }, { name: c.title, path }])} />
      <header className="lp-hero"><span className="lp-badge">{c.category.toUpperCase()}</span><h1>{c.title}</h1><p className="lp-lead">{c.summary}</p></header>
      <section className="lp-sec"><div className="lp-wrap">
        <h2>The Problem</h2><p>{c.problem}</p>
        <h2>Our Solution</h2><p>{c.solution}</p>
        <h2>Key Features</h2><List items={c.features} />
        <h2 style={{ marginTop: 30 }}>Technology</h2><List items={c.tech} />
        <h2 style={{ marginTop: 30 }}>Results</h2><List items={c.results} />
        <div className="lp-cta" style={{ marginTop: 36, justifyContent: 'flex-start' }}>
          <Link to="/contact" className="lp-btn primary">Get a Similar Solution</Link>
          {c.related && <Link to={`/${c.related}`} className="lp-btn ghost">Learn More</Link>}
        </div>
      </div></section>
    </div>
  )
}
export default CaseStudyPage
