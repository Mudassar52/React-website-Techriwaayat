import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import './LandingPage.css'

const NotFound = () => (
  <div className="lp">
    <SEO title="Page Not Found" description="The page you are looking for does not exist." path="/404" noindex />
    <header className="lp-hero">
      <span className="lp-badge">ERROR 404</span>
      <h1>Page Not Found</h1>
      <p className="lp-lead">The page you requested does not exist or has moved. Try one of these instead.</p>
      <div className="lp-cta">
        <Link to="/" className="lp-btn primary">Home</Link>
        <Link to="/solutions" className="lp-btn ghost">Our Solutions</Link>
        <Link to="/contact" className="lp-btn ghost">Contact</Link>
      </div>
    </header>
  </div>
)
export default NotFound
