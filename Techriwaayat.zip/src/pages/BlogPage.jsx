import React, { useEffect } from 'react'
import { FaCalendarAlt, FaUserEdit, FaArrowRight, FaPaperPlane } from 'react-icons/fa'
import { Link } from 'react-router-dom'
import AOS from 'aos'
import './BlogPage.css'
import SEO, { breadcrumbLd } from '../components/SEO'
import { blogPosts, formatDate } from '../data/blogPosts'

const BlogPage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    AOS.refresh();
  }, [])

  const [featured, ...rest] = blogPosts

  return (
    <div className="blog-page">
      <SEO
        title="Software, POS & Business Tech Blog Pakistan"
        description="Practical guides on POS software, inventory systems, custom software and choosing a software house in Pakistan, from the Tech Riwaayat team."
        path="/blog"
        jsonLd={breadcrumbLd([{name:'Home',path:'/'},{name:'Blog',path:'/blog'}])}
      />
      {/* Hero Section */}
      <section className="blog-hero">
        <div className="blog-hero-content" data-aos="fade-up">
          <h1 className="blog-title">Software & <span className="highlight">Business Guides</span></h1>
          <p className="blog-subtitle">Practical guides on POS, inventory, custom software and choosing the right software partner in Pakistan.</p>
        </div>
      </section>

      {/* Featured Post Section */}
      <section className="featured-post-section">
        <div className="featured-post-card" data-aos="fade-up" data-aos-delay="100">
          <div className="featured-img-container">
            <img src={featured.image} alt={featured.title} loading="eager" decoding="async" />
          </div>
          <div className="featured-content">
            <span className="post-category">{featured.category}</span>
            <h2 className="featured-title">{featured.title}</h2>
            <p className="featured-excerpt">{featured.excerpt}</p>
            
            <div className="post-meta">
              <div className="meta-item"><FaCalendarAlt /> {formatDate(featured.date)}</div>
              <div className="meta-item"><FaUserEdit /> {featured.author}</div>
            </div>
            
            <Link to={featured.path} className="btn btn-primary" style={{marginTop: '24px', alignSelf: 'flex-start', textDecoration: 'none'}}>Read Article</Link>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="blog-grid-section">
        <div className="section-header" data-aos="fade-up">
          <h2>Latest Articles</h2>
        </div>
        
        <div className="blog-grid">
          {rest.map((post, index) => (
            <article className="blog-card" key={post.slug} data-aos="fade-up" data-aos-delay={index * 50}>
              <Link to={post.path} style={{textDecoration: 'none', color: 'inherit', display: 'flex', flexDirection: 'column', height: '100%'}}>
                <div className="blog-img">
                  <img src={post.image} alt={post.title} loading="lazy" decoding="async" />
                </div>
                <div className="blog-card-content">
                  <span className="post-category">{post.category}</span>
                  <h3 className="blog-card-title">{post.title}</h3>
                  <p className="blog-card-excerpt">{post.excerpt}</p>
                  
                  <div className="post-meta" style={{marginBottom: '16px'}}>
                    <div className="meta-item"><FaCalendarAlt /> {formatDate(post.date)}</div>
                  </div>
                  
                  <span className="read-more">Read More <FaArrowRight /></span>
                </div>
              </Link>
            </article>
          ))}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="newsletter-section">
        <div className="newsletter-container" data-aos="zoom-in">
          <h2 className="newsletter-title">Subscribe to Our Newsletter</h2>
          <p className="newsletter-subtitle">Get the latest tech news, tutorials, and insights delivered directly to your inbox every week.</p>
          
          <form className="newsletter-form" onSubmit={(e) => e.preventDefault()}>
            <input type="email" className="newsletter-input" placeholder="Enter your email address" required />
            <button type="submit" className="newsletter-btn">Subscribe <FaPaperPlane style={{marginLeft: '8px'}} /></button>
          </form>
        </div>
      </section>
    </div>
  )
}

export default BlogPage
