import React from 'react'
import Hero from '../components/Hero'
import Clients from '../components/Clients'
import Services from '../components/Services'
import Industries from '../components/Industries'
import About from '../components/About'
import TechStack from '../components/TechStack'
import CTA from '../components/CTA'
import Process from '../components/Process'
import TeamPreview from '../components/TeamPreview'
import Pricing from '../components/Pricing'
import FAQ from '../components/FAQ'
import Contact from '../components/Contact'
import SEO from '../components/SEO'
import SolutionsGrid from '../components/SolutionsGrid'
import { SITE } from '../config/site'

const organizationJsonLd = [{
  '@context': 'https://schema.org',
  '@type': ['ProfessionalService', 'Organization'],
  '@id': `${SITE.url}/#organization`,
  name: SITE.name,
  url: SITE.url,
  logo: `${SITE.url}/favicon.png`,
  image: `${SITE.url}/og-image.png`,
  description: 'Software house in Pakistan building custom software, POS and inventory systems, ERP, websites, e-commerce, mobile apps and AI automation.',
  telephone: SITE.phoneE164,
  email: SITE.email,
  areaServed: { '@type': 'Country', name: 'Pakistan' },
  address: { '@type': 'PostalAddress', addressLocality: SITE.city, addressRegion: SITE.region, addressCountry: SITE.country },
  sameAs: SITE.social,
}, {
  '@context': 'https://schema.org', '@type': 'WebSite', name: SITE.name, url: SITE.url,
}]

const Home = () => {
  return (
    <div className="home-page">
      <SEO
        fullTitle
        title="Software House in Pakistan | Custom Software, POS & Web"
        description="Tech Riwaayat is a software house in Pakistan building custom software, POS, inventory, ERP, websites and mobile apps. Get a free quote today."
        path="/"
        jsonLd={organizationJsonLd}
      />
      <Hero />
      <Clients />
      <Services />
      <SolutionsGrid title="Software & Web Solutions We Build in Pakistan" intro="Not sure where to start? Pick the solution closest to your business and see what it includes." slugs={['software-house-in-pakistan','pos-software-development-company-pakistan','restaurant-pos-software-pakistan','inventory-management-software-pakistan','erp-software-development-pakistan','custom-software-development-pakistan','web-development-company-pakistan','ecommerce-development-company-pakistan','react-development-company-pakistan']} />
      <Industries />
      <About />
      <TechStack />
      <CTA />
      <Process />
      <TeamPreview />
      <Pricing />
      <FAQ />
      <Contact />
    </div>
  )
}

export default Home
