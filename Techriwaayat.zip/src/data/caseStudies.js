// ADD REAL PROJECTS HERE. Portfolio pages stay hidden (noindex, not in sitemap/nav)
// until at least one entry exists. Example shape:
//
// {
//   slug: 'restaurant-pos-software-lahore',
//   title: 'Restaurant POS Software for a Cafe Chain in Lahore',
//   category: 'Restaurant POS',
//   summary: 'One-line result-focused summary.',
//   date: '2026-09-01',
//   image: '/portfolio/restaurant-pos.jpg',
//   problem: 'What the client struggled with.',
//   solution: 'What you built.',
//   features: ['Table management', 'KOT', 'Daily reports'],
//   tech: ['React', 'Node.js', 'MySQL'],
//   results: ['Billing time reduced', 'Daily stock visibility'],
//   related: 'restaurant-pos-software-pakistan',   // slug of a landing page
// }
export const caseStudies = []
export const caseStudyBySlug = Object.fromEntries(caseStudies.map(c => [c.slug, c]))
