// Keyword landing pages. Each entry becomes /<slug>. Content is plain data so the
// prerender script can also read it (no JSX in this file).
export const seoPages = [
{
 slug: 'software-house-in-pakistan', badge: 'SOFTWARE HOUSE IN PAKISTAN',
 title: 'Software House in Pakistan | Custom Software, Web & Apps',
 description: 'Tech Riwaayat is a software house in Pakistan building custom software, POS & inventory systems, websites and mobile apps for growing businesses. Get a free quote.',
 h1: 'Software House in Pakistan for Businesses That Want Results',
 intro: ['Tech Riwaayat is a Pakistan-based software house that designs and builds the software your business actually runs on: billing and POS systems, inventory and ERP tools, websites, e-commerce stores and mobile apps.','We work with shop owners, wholesalers, restaurants, clinics, startups and established companies. You talk to the people who build the product, not a sales layer, and you get a clear scope, timeline and price before we write a line of code.'],
 features: [['Custom software','Systems built around your workflow, not a generic template.'],['POS & inventory','Billing, stock, purchases, suppliers and daily reports in one place.'],['Websites & e-commerce','Fast, SEO-ready sites and online stores that turn visitors into orders.'],['Mobile apps','Android and iOS apps connected to your business data.'],['ERP & management systems','Sales, accounts, HR and reporting for multi-branch teams.'],['Support & maintenance','Updates, backups and quick fixes after launch.']],
 audience: ['Retail shops and wholesalers','Restaurants and cafes','Clinics, pharmacies and labs','Startups and growing companies'],
 faqs: [['What does a software house do?','A software house designs, builds and maintains software for other businesses, from websites and mobile apps to POS, inventory and ERP systems.'],['How do I choose a software house in Pakistan?','Look for relevant past work, clear scope and pricing, direct communication with developers, and support after delivery. Ask for a demo of something similar to what you need.'],['Do you work with clients outside my city?','Yes. We work remotely with clients across Pakistan and abroad using calls, WhatsApp and shared project boards.']],
 related: ['custom-software-development-pakistan','pos-software-development-company-pakistan','web-development-company-pakistan','mobile-app-development-company-pakistan']
},
{
 slug: 'software-development-company-pakistan', badge: 'SOFTWARE DEVELOPMENT COMPANY',
 title: 'Software Development Company in Pakistan | Tech Riwaayat',
 description: 'Looking for a software development company in Pakistan? Tech Riwaayat delivers web apps, mobile apps, POS, ERP and AI automation with clear scope and support.',
 h1: 'Software Development Company in Pakistan',
 intro: ['We take a software idea or a messy manual process and turn it into a working, maintainable product. Our team covers discovery, UI/UX design, development, testing, deployment and long-term support.','Projects start with a short scoping call and a written proposal. From there you get regular demos so you see progress early and can change direction before it becomes expensive.'],
 features: [['Discovery & scoping','We map your process, users and priorities before building.'],['UI/UX design','Clean, simple screens your staff can learn quickly.'],['Full-stack development','React, Node.js, PHP/Laravel, Python and modern databases.'],['Testing & QA','Manual and automated checks before every release.'],['Deployment','Hosting setup, domains, SSL, backups and monitoring.'],['Post-launch support','Bug fixes, upgrades and new features as you grow.']],
 audience: ['Businesses replacing Excel or paper','Startups building an MVP','Companies modernising old software','Teams needing a dedicated developer'],
 faqs: [['How long does software development take?','A focused MVP often takes a few weeks; larger systems such as ERP take a few months. You get a timeline after scoping.'],['Who owns the source code?','You do, once the project is completed and paid for.'],['Can you improve software we already have?','Yes. We can audit, fix, extend or rebuild existing systems.']],
 related: ['software-house-in-pakistan','custom-software-development-pakistan','erp-software-development-pakistan','react-development-company-pakistan']
},
{
 slug: 'web-development-company-pakistan', badge: 'WEB DEVELOPMENT COMPANY',
 title: 'Web Development Company in Pakistan | Business Websites',
 description: 'Tech Riwaayat is a web development company in Pakistan building fast, mobile-friendly, SEO-ready websites, web apps and online stores. Request a quote today.',
 h1: 'Web Development Company in Pakistan',
 intro: ['Your website should bring in enquiries, not just exist. We build responsive business websites, portals and web applications that load quickly, look professional on mobile and are structured properly for Google.','Whether you need a simple company site, a custom web app with logins and dashboards, or a redesign of an old site, we plan the pages around what your customers search for and what you want them to do next.'],
 features: [['Business websites','Service pages, portfolio, blog and clear contact paths.'],['Custom web apps','Dashboards, portals, booking and management tools.'],['SEO-ready structure','Clean URLs, meta data, schema and sitemap from day one.'],['Speed & performance','Optimised images and code for good Core Web Vitals.'],['Responsive design','Built for phones first, then tablets and desktops.'],['CMS options','WordPress or custom admin so you can edit content yourself.']],
 audience: ['Local businesses wanting more leads','Companies with outdated websites','Startups needing a web platform','Agencies needing a development partner'],
 faqs: [['How much does a website cost in Pakistan?','It depends on pages, features and design effort. A simple brochure site costs far less than a custom web app. Share your requirements and we will send a written quote.'],['Will my website rank on Google?','We build it SEO-ready, but rankings also depend on content, competition and links. We can add ongoing SEO if you want.'],['Do you provide hosting and domain help?','Yes, we can set up and manage hosting, domain, SSL and email.']],
 related: ['react-development-company-pakistan','wordpress-development-company-pakistan','ecommerce-development-company-pakistan','seo-services-pakistan']
},
{
 slug: 'custom-software-development-pakistan', badge: 'CUSTOM SOFTWARE DEVELOPMENT',
 title: 'Custom Software Development Pakistan | Built for Your Business',
 description: 'Custom software development in Pakistan for businesses that outgrew Excel and off-the-shelf tools. Tailored web, desktop and mobile systems by Tech Riwaayat.',
 h1: 'Custom Software Development in Pakistan',
 intro: ['Off-the-shelf software makes you change how you work. Custom software does the opposite: it is designed around your approvals, pricing rules, reports and staff roles.','We build custom systems for operations, sales, inventory, accounting, HR and customer management, with role-based access, audit trails and reports your management actually needs.'],
 features: [['Workflow automation','Replace repeated manual steps with rules and approvals.'],['Role-based access','Owners, managers and staff see only what they should.'],['Reports & dashboards','Sales, stock, profit and performance at a glance.'],['Integrations','Connect payments, SMS, WhatsApp, accounting and courier APIs.'],['Data migration','Move data safely from Excel or old software.'],['Scalable architecture','Add branches, users and modules without a rebuild.']],
 audience: ['Businesses with unique processes','Multi-branch operations','Companies stuck on Excel','Founders building a product'],
 faqs: [['Why choose custom software over ready-made?','Custom software fits your exact process, avoids per-user license fees and can grow with you. Ready-made suits simple, standard needs.'],['Can you migrate our Excel data?','Yes. We clean and import existing data so you can start using the system quickly.'],['Do you offer training?','Yes, we train your team and provide simple guides.']],
 related: ['erp-software-development-pakistan','inventory-management-software-pakistan','software-development-company-pakistan','ai-automation-company-pakistan']
},
{
 slug: 'pos-software-development-company-pakistan', badge: 'POS SOFTWARE DEVELOPMENT',
 title: 'POS Software Development Company in Pakistan | Tech Riwaayat',
 description: 'POS software development company in Pakistan. Custom point of sale systems with billing, inventory, receipts, reports and multi-branch support. Get a free demo.',
 h1: 'POS Software Development Company in Pakistan',
 intro: ['A good POS is fast at the counter and honest in the back office. We build point of sale software for shops, restaurants, pharmacies and wholesalers that handles billing, discounts, taxes, returns, stock deduction and end-of-day cash reports.','Because the system is built for your business, you can add the things packaged POS tools charge extra for: custom receipts, barcode workflows, credit ledgers, salesman targets or branch-wise pricing.'],
 features: [['Fast billing','Barcode scan, quick search, hold/resume bills and keyboard shortcuts.'],['Receipt printing','Thermal and A4 invoices with your branding.'],['Live inventory','Stock updates automatically with every sale, purchase and return.'],['Customer & supplier ledgers','Credit sales, payments and outstanding balances.'],['Daily reports','Sales, profit, cash in hand and top-selling items.'],['Multi-branch & users','Central control with cashier and manager permissions.']],
 audience: ['Grocery and general stores','Clothing and shoe shops','Spare parts and hardware stores','Restaurants, bakeries and cafes'],
 faqs: [['Can the POS work without internet?','Yes, we can build offline-capable POS that syncs when the connection returns.'],['Can I connect a barcode scanner and thermal printer?','Yes, standard USB barcode scanners and thermal receipt printers are supported.'],['Can I see sales from my phone?','We can add a mobile-friendly dashboard so owners can check sales and stock remotely.']],
 related: ['retail-pos-software-pakistan','restaurant-pos-software-pakistan','inventory-management-software-pakistan','pharmacy-management-software-pakistan']
},
{
 slug: 'restaurant-pos-software-pakistan', badge: 'RESTAURANT POS SOFTWARE',
 title: 'Restaurant POS Software in Pakistan | Orders, KOT & Reports',
 description: 'Restaurant POS software in Pakistan with table management, KOT, kitchen display, delivery orders, recipes and daily sales reports. Book a free demo.',
 h1: 'Restaurant POS Software in Pakistan',
 intro: ['Restaurants lose money in small leaks: missed orders, wrong bills, untracked stock and unclear daily sales. A restaurant POS closes those gaps by taking the order once and carrying it to the kitchen, the bill and the report.','We build restaurant and cafe POS systems for dine-in, takeaway and delivery, with table-wise orders, kitchen order tickets (KOT), split bills and menu-wise sales insights.'],
 features: [['Table & order management','Open, merge, transfer and split table bills.'],['KOT & kitchen display','Orders reach the kitchen instantly, with no shouting or paper slips.'],['Delivery & takeaway','Track rider, address and order status.'],['Recipe-based stock','Deduct ingredients automatically per dish.'],['Discounts & taxes','Item, bill and staff discounts with tax handling.'],['Owner reports','Day-wise sales, best dishes, waiter performance and expenses.']],
 audience: ['Restaurants and dhabas','Cafes and bakeries','Fast food outlets','Cloud kitchens'],
 faqs: [['Does it support KOT printing?','Yes, KOTs can print to kitchen printers or show on a kitchen screen.'],['Can it track ingredient stock?','Yes. With recipes set up, stock is deducted as dishes are sold.'],['Can I run multiple branches?','Yes. Manage menus and view sales for every branch from one login.']],
 related: ['pos-software-development-company-pakistan','inventory-management-software-pakistan','retail-pos-software-pakistan','mobile-app-development-company-pakistan']
},
{
 slug: 'inventory-management-software-pakistan', badge: 'INVENTORY MANAGEMENT SOFTWARE',
 title: 'Inventory Management Software Pakistan | Stock Control System',
 description: 'Inventory management software in Pakistan for shops, wholesalers and warehouses. Track stock, purchases, suppliers, low-stock alerts and profit. Free demo.',
 h1: 'Inventory Management Software in Pakistan',
 intro: ['When stock lives in notebooks and Excel sheets, you find out about shortages and losses too late. Inventory management software gives you a live count of what you have, what is selling and what to reorder.','We build stock systems for shops, wholesalers, distributors and warehouses: purchase entry, sales, returns, batch and expiry, stock transfers between branches, and low-stock alerts.'],
 features: [['Real-time stock','Every sale and purchase updates quantity automatically.'],['Purchase & supplier management','Purchase orders, supplier ledgers and payments.'],['Low-stock alerts','Know what to reorder before you run out.'],['Batch & expiry','Essential for pharmacies, food and cosmetics.'],['Multi-warehouse','Transfer stock between branches and godowns.'],['Barcode support','Generate labels and scan items quickly.']],
 audience: ['Wholesalers and distributors','Retail chains','Pharmacies and medical stores','Warehouses and godowns'],
 faqs: [['Can it replace Excel for stock?','Yes. We import your existing item list and opening stock, then track everything live.'],['Does it show profit?','Yes, item-wise and period-wise profit based on purchase and sale prices.'],['Can it work with a POS?','Yes, inventory and POS share the same data so stock is always current.']],
 related: ['wholesale-distribution-software-pakistan','pos-software-development-company-pakistan','pharmacy-management-software-pakistan','erp-software-development-pakistan']
},
{
 slug: 'erp-software-development-pakistan', badge: 'ERP SOFTWARE DEVELOPMENT',
 title: 'ERP Software Development in Pakistan | Custom ERP Systems',
 description: 'ERP software development in Pakistan: custom ERP for sales, inventory, accounts, HR and reporting. Modular, scalable systems by Tech Riwaayat.',
 h1: 'ERP Software Development in Pakistan',
 intro: ['An ERP joins the departments of a business into one system so sales, stock, accounts and HR stop working from different spreadsheets. The trouble with big ERP packages is cost and complexity you may never use.','We build modular ERP systems: start with the modules that solve your biggest problem, such as sales and inventory, and add accounting, HR, CRM or manufacturing later.'],
 features: [['Sales & purchase','Quotations, orders, invoices and supplier bills.'],['Inventory & warehouse','Stock across locations with full movement history.'],['Accounting','Ledgers, receivables, payables, expenses and financial statements.'],['HR & payroll','Attendance, leave, salary sheets and employee records.'],['CRM','Leads, follow-ups and customer history.'],['Management dashboards','KPIs and reports for owners and department heads.']],
 audience: ['Growing SMEs','Distribution and trading companies','Small manufacturers','Multi-branch businesses'],
 faqs: [['Do I need a full ERP from day one?','No. A phased, modular approach keeps cost and risk lower.'],['Can the ERP be accessed remotely?','Yes, it can be web-based so owners and managers can log in from anywhere.'],['Can you integrate our current tools?','Yes, we can connect existing accounting, payment or e-commerce systems.']],
 related: ['custom-software-development-pakistan','inventory-management-software-pakistan','wholesale-distribution-software-pakistan','software-development-company-pakistan']
},
{
 slug: 'ecommerce-development-company-pakistan', badge: 'E-COMMERCE DEVELOPMENT',
 title: 'E-commerce Development Company in Pakistan | Online Stores',
 description: 'E-commerce development company in Pakistan building Shopify, WooCommerce and custom online stores with local payments, courier integration and SEO.',
 h1: 'E-commerce Development Company in Pakistan',
 intro: ['An online store in Pakistan has to handle things global templates ignore: cash on delivery, local payment gateways, courier booking, city-based shipping and WhatsApp-first customers.','We build e-commerce stores on WooCommerce, Shopify or custom stacks, wired to your inventory and courier workflow, and structured so product and category pages can rank on Google.'],
 features: [['Store setup','Catalogue, variants, coupons and checkout flow.'],['Local payments','Cash on delivery, bank transfer and Pakistani payment gateways.'],['Courier integration','Order booking and tracking with local couriers.'],['Inventory sync','Keep website and shop or warehouse stock aligned.'],['Product SEO','Clean URLs, schema and fast product pages.'],['Admin dashboard','Manage orders, customers and sales without coding.']],
 audience: ['Fashion and lifestyle brands','Retailers going online','Wholesalers with B2B ordering','Home-based brands and startups'],
 faqs: [['Shopify or WooCommerce?','Shopify is quick to launch; WooCommerce gives more control and lower recurring cost. We recommend based on your products and budget.'],['Can you add cash on delivery?','Yes, COD and local payment methods can be configured.'],['Can the store connect to my POS?','Yes, we can sync stock and orders with a POS or inventory system.']],
 related: ['web-development-company-pakistan','wordpress-development-company-pakistan','inventory-management-software-pakistan','seo-services-pakistan']
},
{
 slug: 'react-development-company-pakistan', badge: 'REACT DEVELOPMENT COMPANY',
 title: 'React Development Company in Pakistan | React.js Experts',
 description: 'React development company in Pakistan. Tech Riwaayat builds fast React.js web apps, dashboards, SaaS products and SEO-friendly frontends. Hire React developers.',
 h1: 'React Development Company in Pakistan',
 intro: ['React is our daily tool. We use it to build dashboards, admin panels, customer portals, SaaS products and marketing sites that feel instant and stay easy to maintain.','You can hire us for a complete product, or bring in React developers to extend your team. We pair React with Node.js, Laravel, Firebase or REST/GraphQL APIs and set up prerendering or SSR where SEO matters.'],
 features: [['Web applications','Single-page apps with authentication and role-based screens.'],['Dashboards & admin panels','Charts, tables and reporting interfaces.'],['SaaS products','Multi-tenant apps with subscriptions and billing.'],['API integration','Connect to your backend, payment and third-party services.'],['SEO-friendly React','Prerendering, meta management and performance tuning.'],['Migration & upgrades','Move legacy jQuery or PHP frontends to React.']],
 audience: ['Startups building an MVP','Companies needing dashboards','Agencies needing React capacity','Teams modernising legacy apps'],
 faqs: [['Is React good for SEO?','Yes, when set up properly with prerendering or server rendering, correct meta tags and fast loading.'],['Can I hire React developers from you?','Yes, either as a fixed-scope project or as dedicated developers.'],['Do you also do the backend?','Yes, we build the API and database as well.']],
 related: ['web-development-company-pakistan','software-development-company-pakistan','mobile-app-development-company-pakistan','custom-software-development-pakistan']
},
{
 slug: 'retail-pos-software-pakistan', badge: 'RETAIL POS SOFTWARE',
 title: 'Retail POS Software in Pakistan | Shop Billing & Stock',
 description: 'Retail POS software in Pakistan for shops and multi-branch stores: fast billing, barcode, stock, customer ledgers and profit reports. Ask for a demo.',
 h1: 'Retail POS Software in Pakistan',
 intro: ['Retail runs on speed at the counter and accuracy in stock. Our retail POS handles quick billing, returns and exchanges, discounts, customer credit and daily closing, while keeping stock correct in the background.','It suits general stores, clothing and shoe shops, mobile and electronics shops, cosmetics, hardware and more, with item variants like size and colour where needed.'],
 features: [['Quick billing','Barcode, search and hold bills for busy counters.'],['Returns & exchanges','Handle them with correct stock and cash impact.'],['Variants','Size, colour and model tracking.'],['Loyalty & discounts','Customer discounts and promotions.'],['Cash closing','Opening, closing and cash difference reports.'],['Multi-branch','Central stock and sales view across shops.']],
 audience: ['General and grocery stores','Clothing and footwear shops','Mobile and electronics shops','Cosmetics and gift shops'],
 faqs: [['Can it handle sizes and colours?','Yes, item variants are supported.'],['Is customer credit (udhaar) supported?','Yes, with customer ledgers and payment tracking.'],['Can I use it on more than one counter?','Yes, multiple counters and cashiers are supported.']],
 related: ['pos-software-development-company-pakistan','inventory-management-software-pakistan','restaurant-pos-software-pakistan','wholesale-distribution-software-pakistan']
},
{
 slug: 'pharmacy-management-software-pakistan', badge: 'PHARMACY SOFTWARE',
 title: 'Pharmacy Management Software in Pakistan | POS with Expiry',
 description: 'Pharmacy management software in Pakistan with batch and expiry tracking, medicine POS, supplier ledgers and reports for medical stores. Book a free demo.',
 h1: 'Pharmacy Management Software in Pakistan',
 intro: ['Medical stores need more than a normal POS: batch numbers, expiry dates, strip and pack units, and supplier credit. Missing any of these means expired stock and lost margin.','Our pharmacy software tracks medicines by batch, warns before expiry, handles loose and pack sales and keeps supplier and customer accounts clear.'],
 features: [['Batch & expiry tracking','Alerts before medicines expire.'],['Unit conversion','Sell by strip, box or pack from one stock.'],['Medicine search','Search by brand, generic name or company.'],['Supplier accounts','Purchase entry, dues and returns.'],['Fast billing','Counter-friendly screen with receipts.'],['Reports','Sales, profit, near-expiry and low-stock.']],
 audience: ['Medical stores','Hospital pharmacies','Pharmacy chains','Distributors of medicines'],
 faqs: [['Does it track expiry?','Yes, with batch-wise expiry and near-expiry reports.'],['Can I import my medicine list?','Yes, from Excel or CSV.'],['Does it work with barcode scanners?','Yes, standard scanners are supported.']],
 related: ['inventory-management-software-pakistan','pos-software-development-company-pakistan','clinic-management-software-pakistan','retail-pos-software-pakistan']
},
{
 slug: 'mobile-app-development-company-pakistan', badge: 'MOBILE APP DEVELOPMENT',
 title: 'Mobile App Development Company in Pakistan | Android & iOS',
 description: 'Mobile app development company in Pakistan building Android and iOS apps with React Native and Flutter for businesses, startups and delivery services.',
 h1: 'Mobile App Development Company in Pakistan',
 intro: ['A mobile app makes sense when your customers or staff need something in their pocket: ordering, booking, tracking, field sales or approvals. We build apps that connect to your website and business software so data stays in one place.','We use cross-platform tools like React Native and Flutter to ship Android and iOS from one codebase, and go native where performance demands it.'],
 features: [['Android & iOS','One codebase, two platforms, faster delivery.'],['Ordering & delivery apps','Catalogue, cart, payments and live order status.'],['Field & staff apps','Sales visits, attendance and task tracking.'],['Push notifications','Bring customers back with timely messages.'],['Backend & API','Secure server and admin panel included.'],['Store publishing','Help with Play Store and App Store release.']],
 audience: ['Restaurants and retailers','Startups','Service and booking businesses','Companies with field teams'],
 faqs: [['React Native or Flutter?','Both are solid. We pick based on your features, team and long-term plans.'],['Do you publish the app on the stores?','Yes, we handle listing, screenshots and submission.'],['Can the app connect to my existing software?','Yes, through APIs.']],
 related: ['react-development-company-pakistan','ecommerce-development-company-pakistan','software-house-in-pakistan','restaurant-pos-software-pakistan']
},
{
 slug: 'wholesale-distribution-software-pakistan', badge: 'WHOLESALE SOFTWARE',
 title: 'Wholesale & Distribution Software in Pakistan | Dealer Ledger',
 description: 'Wholesale and distribution software in Pakistan: dealer ledgers, price tiers, salesman orders, multi-godown stock and recovery tracking. Get a demo.',
 h1: 'Wholesale & Distribution Software in Pakistan',
 intro: ['Wholesale is a credit business: many customers, many prices, and money out in the market. The software has to make dealer ledgers, recoveries and stock movement obvious.','We build distribution systems with customer-wise price levels, salesman orders, delivery tracking, multi-godown stock and clear outstanding reports.'],
 features: [['Dealer & customer ledgers','Balances, payments and aging.'],['Price tiers','Different rates for different customer types.'],['Salesman orders','Take orders in the field and sync to the office.'],['Multi-godown stock','Track stock across warehouses.'],['Recovery tracking','Follow up on outstanding payments.'],['Route & area reports','Sales by route, salesman or area.']],
 audience: ['Wholesalers','Distributors','Traders','Company sales offices'],
 faqs: [['Can salesmen place orders from a phone?','Yes, via a mobile-friendly order screen or app.'],['Can I set different prices per customer?','Yes, through price levels and special rates.'],['Does it track outstanding payments?','Yes, with ledgers and aging reports.']],
 related: ['inventory-management-software-pakistan','erp-software-development-pakistan','pos-software-development-company-pakistan','custom-software-development-pakistan']
},
{
 slug: 'clinic-management-software-pakistan', badge: 'CLINIC SOFTWARE',
 title: 'Clinic Management Software in Pakistan | Patients & Billing',
 description: 'Clinic management software in Pakistan for doctors and small hospitals: patient records, appointments, prescriptions, billing and reports. Free demo available.',
 h1: 'Clinic Management Software in Pakistan',
 intro: ['Clinics need quick registration, tidy patient history and correct billing without slowing down the doctor. Paper files and separate registers make follow-up and reporting hard.','We build clinic software with patient records, appointment scheduling, prescriptions, lab and fee billing, and daily revenue reports, with access limited by role.'],
 features: [['Patient records','History, visits and documents in one profile.'],['Appointments','Schedules and reminders for patients.'],['Prescriptions','Templates and printable prescriptions.'],['Billing','Consultation, procedure and lab fees.'],['Role-based access','Doctor, receptionist and admin permissions.'],['Reports','Daily revenue, patient count and doctor-wise summaries.']],
 audience: ['Private clinics','Dental and skin clinics','Diagnostic labs','Small hospitals'],
 faqs: [['Is patient data secure?','We use role-based access, secure hosting and regular backups.'],['Can it print prescriptions?','Yes, with your clinic branding.'],['Can I add a lab or pharmacy module?','Yes, modules can be added later.']],
 related: ['pharmacy-management-software-pakistan','custom-software-development-pakistan','erp-software-development-pakistan','software-house-in-pakistan']
},
{
 slug: 'wordpress-development-company-pakistan', badge: 'WORDPRESS DEVELOPMENT',
 title: 'WordPress Development Company in Pakistan | Themes & WooCommerce',
 description: 'WordPress development company in Pakistan: custom themes, plugins, WooCommerce stores, speed and security. Easy-to-manage sites by Tech Riwaayat.',
 h1: 'WordPress Development Company in Pakistan',
 intro: ['WordPress powers a large share of business sites because you can manage content yourself. Done poorly it is slow and insecure; done well it is fast, flexible and SEO-friendly.','We build custom themes and plugins, WooCommerce stores, and fix speed, security and hacked-site issues, keeping the admin simple for your team.'],
 features: [['Custom themes','Designed for your brand, not a bloated template.'],['Custom plugins','Features specific to your business.'],['WooCommerce','Online stores with local payment and courier options.'],['Speed optimisation','Caching, image and code clean-up.'],['Security hardening','Firewall, backups and malware clean-up.'],['Maintenance','Updates and support plans.']],
 audience: ['Business websites','Bloggers and publishers','Online stores','Sites needing a speed or security fix'],
 faqs: [['Can I edit the site myself?','Yes, we set up an easy admin and can train you.'],['Can you fix a hacked WordPress site?','Yes, we clean, secure and restore it.'],['WordPress or custom code?','WordPress suits content-led sites and shops; custom code suits complex apps.']],
 related: ['web-development-company-pakistan','ecommerce-development-company-pakistan','seo-services-pakistan','react-development-company-pakistan']
},
{
 slug: 'ai-automation-company-pakistan', badge: 'AI AUTOMATION',
 title: 'AI Automation Company in Pakistan | Chatbots & Workflow Automation',
 description: 'AI automation company in Pakistan building chatbots, WhatsApp automation, document processing and internal AI tools that cut manual work and cost.',
 h1: 'AI Automation Company in Pakistan',
 intro: ['Many businesses spend hours on repeated tasks: answering the same customer questions, copying data between systems, preparing reports. AI and workflow automation can take over a large part of that.','We build practical automations: WhatsApp and website chatbots, lead qualification, document and invoice data extraction, and internal AI assistants connected to your own data.'],
 features: [['Chatbots','Answer common customer questions on your website and WhatsApp.'],['Lead qualification','Collect and route enquiries automatically.'],['Document processing','Extract data from invoices and forms.'],['Workflow automation','Connect your tools and remove copy-paste work.'],['Internal AI assistants','Search and summarise your company knowledge.'],['Reporting automation','Scheduled reports sent to your team.']],
 audience: ['Customer support teams','Sales and marketing teams','Finance and operations teams','Agencies'],
 faqs: [['Will AI replace my staff?','It removes repetitive tasks so staff can focus on work that needs judgment.'],['Is my data safe?','We design with access controls and only use the data needed for the task.'],['Where do I start?','Pick one repetitive task with clear rules; we automate it first and expand.']],
 related: ['custom-software-development-pakistan','software-development-company-pakistan','web-development-company-pakistan','erp-software-development-pakistan']
},
{
 slug: 'seo-services-pakistan', badge: 'SEO SERVICES',
 title: 'SEO Services in Pakistan | Rank Higher & Get More Leads',
 description: 'SEO services in Pakistan: technical SEO, keyword research, content and local SEO to help your business rank on Google and generate qualified leads.',
 h1: 'SEO Services in Pakistan',
 intro: ['SEO works when it targets the searches your buyers actually make, on a site Google can crawl quickly. We start with a technical audit and keyword research, then fix, build and publish.','Our approach combines technical SEO, service and location pages, useful content and Google Business Profile optimisation, with monthly reporting on rankings, traffic and enquiries.'],
 features: [['Technical SEO audit','Crawlability, speed, schema and indexing issues.'],['Keyword research','Find search terms that bring buyers, not just visitors.'],['On-page SEO','Titles, headings, content and internal links.'],['Local SEO','Google Business Profile, citations and reviews.'],['Content strategy','Articles that answer buyer questions.'],['Reporting','Clear monthly numbers on rankings and leads.']],
 audience: ['Service businesses','Software and IT companies','E-commerce stores','Local shops and clinics'],
 faqs: [['How long does SEO take?','Usually a few months to see steady movement, depending on competition and site health.'],['Can you guarantee first-page rankings?','No one honestly can. We focus on proven work and measurable progress.'],['Do you do local SEO?','Yes, including Google Business Profile setup and optimisation.']],
 related: ['web-development-company-pakistan','wordpress-development-company-pakistan','ecommerce-development-company-pakistan','software-house-in-pakistan']
}
]
export const seoPagesBySlug = Object.fromEntries(seoPages.map(p => [p.slug, p]))
