import React from 'react'
import { Link } from 'react-router-dom'
import { seoPages } from '../data/seoPages'
import '../pages/LandingPage.css'

// Internal-link grid: home page + solutions hub. `slugs` optional to limit.
const SolutionsGrid = ({ slugs, title = 'Software & Web Solutions We Build in Pakistan', intro }) => {
  const items = slugs ? slugs.map(s => seoPages.find(p => p.slug === s)).filter(Boolean) : seoPages
  return (
    <section className="lp-sec alt lp">
      <div className="lp-wrap" style={{ paddingTop: 0 }}>
        <h2>{title}</h2>
        {intro && <p>{intro}</p>}
        <div className="lp-grid">
          {items.map(p => (
            <Link key={p.slug} to={`/${p.slug}`} className="lp-card">
              <h3>{p.h1.replace(/ for Businesses.*/, '')}</h3>
              <p>{p.features[0][1]}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
export default SolutionsGrid
