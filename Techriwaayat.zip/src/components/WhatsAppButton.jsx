import React from 'react'
import { FaWhatsapp } from 'react-icons/fa'
import { waLink } from '../config/site'
import '../pages/LandingPage.css'

const WhatsAppButton = () => (
  <a className="wa-float" href={waLink()} target="_blank" rel="noopener noreferrer" aria-label="Chat with Tech Riwaayat on WhatsApp">
    <FaWhatsapp />
  </a>
)
export default WhatsAppButton
