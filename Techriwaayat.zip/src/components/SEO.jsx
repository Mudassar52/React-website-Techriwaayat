import React from 'react'
import { Helmet } from 'react-helmet-async'
import { SITE } from '../config/site'

const DEFAULT_IMAGE = `${SITE.url}/og-image.png`
const DEFAULT_TITLE = 'Software House in Pakistan | Custom Software, POS & Web'

export const breadcrumbLd = (items) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map((it, i) => ({
    '@type': 'ListItem', position: i + 1, name: it.name, item: `${SITE.url}${it.path}`,
  })),
})

export const faqLd = (faqs) => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })),
})

/**
 * Per-page <head> control. `title` is the FULL title when fullTitle=true,
 * otherwise "<title> | Tech Riwaayat" is used. jsonLd can be an object or array.
 */
const SEO = ({ title, description, path = '/', image = DEFAULT_IMAGE, type = 'website', noindex = false, jsonLd = null, fullTitle = false }) => {
  const finalTitle = !title ? DEFAULT_TITLE : fullTitle ? title : `${title} | ${SITE.name}`
  const canonical = `${SITE.url}${path === '/' ? '/' : path}`
  const blocks = jsonLd ? (Array.isArray(jsonLd) ? jsonLd : [jsonLd]) : []

  return (
    <Helmet>
      <title>{finalTitle}</title>
      {description && <meta name="description" content={description} />}
      <link rel="canonical" href={canonical} />
      <meta name="robots" content={noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large'} />
      <meta property="og:type" content={type} />
      <meta property="og:locale" content="en_PK" />
      <meta property="og:site_name" content={SITE.name} />
      <meta property="og:title" content={finalTitle} />
      {description && <meta property="og:description" content={description} />}
      <meta property="og:url" content={canonical} />
      <meta property="og:image" content={image} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={finalTitle} />
      {description && <meta name="twitter:description" content={description} />}
      <meta name="twitter:image" content={image} />
      {blocks.map((b, i) => (
        <script key={i} type="application/ld+json">{JSON.stringify(b)}</script>
      ))}
    </Helmet>
  )
}

export default SEO
