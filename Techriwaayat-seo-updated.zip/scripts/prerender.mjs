// Post-build: writes per-route HTML (real <title>, meta, canonical, JSON-LD, noscript content)
// + sitemap.xml + 404.html into dist/. Static hosting friendly (Hostinger).
import fs from 'node:fs'
import path from 'node:path'
import { SITE } from '../src/config/site.js'
import { seoPages } from '../src/data/seoPages.js'
import { blogPosts } from '../src/data/blogPosts.js'
import { caseStudies } from '../src/data/caseStudies.js'
import { staticRoutes } from '../src/data/routeMeta.js'

const dist = path.resolve('dist')
const tpl = fs.readFileSync(path.join(dist, 'index.html'), 'utf8')
const today = new Date().toISOString().slice(0, 10)
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')
const ld = (o) => `<script type="application/ld+json" data-rh="true">${JSON.stringify(o).replace(/</g, '\\u003c')}</script>`
const crumbs = (items) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: SITE.url + it.path })) })

const routes = []
routes.push({ path: '/', title: 'Software House in Pakistan | Custom Software, POS & Web Development | Tech Riwaayat',
  description: 'Tech Riwaayat is a software house in Pakistan building custom software, POS and inventory systems, ERP, websites, e-commerce and mobile apps. Get a free quote today.',
  h1: 'Software House in Pakistan for Custom Software, POS & Web Development', priority: '1.0', lastmod: today,
  jsonld: [{ '@context': 'https://schema.org', '@type': ['ProfessionalService', 'Organization'], '@id': `${SITE.url}/#organization`, name: SITE.name, url: SITE.url, logo: `${SITE.url}/favicon.png`, image: `${SITE.url}/og-image.png`,
    telephone: SITE.phoneE164, email: SITE.email, areaServed: { '@type': 'Country', name: 'Pakistan' },
    address: { '@type': 'PostalAddress', addressLocality: SITE.city, addressRegion: SITE.region, addressCountry: SITE.country }, sameAs: SITE.social },
    { '@context': 'https://schema.org', '@type': 'WebSite', name: SITE.name, url: SITE.url }],
  links: seoPages.slice(0, 10).map(p => [`/${p.slug}`, p.h1]) })

for (const p of seoPages) {
  routes.push({ path: `/${p.slug}`, title: p.title, description: p.description, h1: p.h1, body: p.intro, priority: '0.9', lastmod: today,
    jsonld: [
      { '@context': 'https://schema.org', '@type': 'Service', name: p.h1, serviceType: p.h1, provider: { '@type': 'ProfessionalService', name: SITE.name, url: SITE.url }, areaServed: { '@type': 'Country', name: 'Pakistan' }, description: p.description },
      { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: p.faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) },
      crumbs([{ name: 'Home', path: '/' }, { name: 'Solutions', path: '/solutions' }, { name: p.h1, path: `/${p.slug}` }])],
    links: p.related.map(r => [`/${r}`, seoPages.find(x => x.slug === r)?.h1 || r]) })
}
for (const r of staticRoutes) routes.push({ ...r, priority: r.path.startsWith('/services') || r.path === '/solutions' || r.path === '/contact' ? '0.8' : r.path.includes('privacy') || r.path.includes('terms') ? '0.2' : '0.6', lastmod: today, jsonld: [crumbs([{ name: 'Home', path: '/' }, { name: r.h1, path: r.path }])] })
for (const b of blogPosts) routes.push({ path: b.path, title: `${b.title} | Tech Riwaayat`, description: b.excerpt, h1: b.title, image: b.image, type: 'article', body: [b.excerpt], priority: '0.7', lastmod: b.date,
  jsonld: [{ '@context': 'https://schema.org', '@type': 'Article', headline: b.title, description: b.excerpt, image: b.image, datePublished: b.date, dateModified: b.date, author: { '@type': 'Organization', name: SITE.name }, publisher: { '@type': 'Organization', name: SITE.name, logo: { '@type': 'ImageObject', url: `${SITE.url}/favicon.png` } }, mainEntityOfPage: SITE.url + b.path },
    crumbs([{ name: 'Home', path: '/' }, { name: 'Blog', path: '/blog' }, { name: b.title, path: b.path }])] })
if (caseStudies.length) {
  routes.push({ path: '/portfolio', title: 'Portfolio & Case Studies | Tech Riwaayat', description: 'Software, POS, web and app projects delivered by Tech Riwaayat.', h1: 'Projects & Case Studies', priority: '0.7', lastmod: today, jsonld: [] })
  for (const c of caseStudies) routes.push({ path: `/portfolio/${c.slug}`, title: `${c.title} | Case Study`, description: c.summary, h1: c.title, body: [c.problem, c.solution], priority: '0.7', lastmod: c.date || today, jsonld: [crumbs([{ name: 'Home', path: '/' }, { name: 'Portfolio', path: '/portfolio' }, { name: c.title, path: `/portfolio/${c.slug}` }])] })
}

function headFor(r, { noindex = false } = {}) {
  const url = SITE.url + (r.path === '/' ? '/' : r.path)
  const img = r.image || `${SITE.url}/og-image.png`
  const t = (s) => s.replace(/^/, '    ')
  return [
    `<title>${esc(r.title)}</title>`,
    `<meta name="description" content="${esc(r.description)}" data-rh="true" />`,
    `<link rel="canonical" href="${url}" data-rh="true" />`,
    `<meta name="robots" content="${noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large'}" data-rh="true" />`,
    `<meta property="og:type" content="${r.type || 'website'}" data-rh="true" />`,
    `<meta property="og:locale" content="en_PK" data-rh="true" />`,
    `<meta property="og:site_name" content="${SITE.name}" data-rh="true" />`,
    `<meta property="og:title" content="${esc(r.title)}" data-rh="true" />`,
    `<meta property="og:description" content="${esc(r.description)}" data-rh="true" />`,
    `<meta property="og:url" content="${url}" data-rh="true" />`,
    `<meta property="og:image" content="${img}" data-rh="true" />`,
    `<meta name="twitter:card" content="summary_large_image" data-rh="true" />`,
    `<meta name="twitter:title" content="${esc(r.title)}" data-rh="true" />`,
    `<meta name="twitter:description" content="${esc(r.description)}" data-rh="true" />`,
    `<meta name="twitter:image" content="${img}" data-rh="true" />`,
    ...(r.jsonld || []).map(ld),
  ].map(t).join('\n')
}
function noscriptFor(r) {
  const links = (r.links || []).map(([h, l]) => `<li><a href="${h}">${esc(l)}</a></li>`).join('')
  return `<noscript><main><h1>${esc(r.h1)}</h1>${(r.body || [r.description]).map(p => `<p>${esc(p)}</p>`).join('')}${links ? `<ul>${links}</ul>` : ''}<p><a href="/contact">Contact Tech Riwaayat</a> · <a href="tel:${SITE.phoneE164}">${SITE.phoneDisplay}</a> · <a href="https://wa.me/${SITE.whatsapp}">WhatsApp</a></p></main></noscript>`
}
function render(r, opts) {
  let html = tpl.replace(/<!--SEO_HEAD-->[\s\S]*?<!--\/SEO_HEAD-->/, `<!--SEO_HEAD-->\n${headFor(r, opts)}\n    <!--/SEO_HEAD-->`)
  return html.replace('<div id="root"></div>', `<div id="root">${noscriptFor(r)}</div>`)
}

for (const r of routes) {
  const out = r.path === '/' ? path.join(dist, 'index.html') : path.join(dist, r.path, 'index.html')
  fs.mkdirSync(path.dirname(out), { recursive: true })
  fs.writeFileSync(out, render(r))
}
fs.writeFileSync(path.join(dist, '404.html'), render({ path: '/404', title: 'Page Not Found | Tech Riwaayat', description: 'The page you are looking for does not exist.', h1: 'Page Not Found', links: [['/', 'Home'], ['/solutions', 'Solutions'], ['/contact', 'Contact']] }, { noindex: true }))

const urls = routes.map(r => `  <url><loc>${SITE.url}${r.path === '/' ? '/' : r.path}</loc><lastmod>${r.lastmod}</lastmod><priority>${r.priority}</priority></url>`).join('\n')
fs.writeFileSync(path.join(dist, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`)
console.log(`Prerendered ${routes.length} routes + 404.html + sitemap.xml`)
