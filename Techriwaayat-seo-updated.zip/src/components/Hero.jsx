import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { waLink } from '../config/site'
import { FaLaptopCode, FaMobileAlt, FaRobot, FaWordpress, FaArrowRight, FaComments } from 'react-icons/fa'
import './Hero.css'

const AnimatedCounter = ({ end, duration = 2000, suffix = '' }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime = null;
    let animationFrameId;
    const endValue = parseInt(end.replace(/\D/g, ''));
    
    if (isNaN(endValue)) {
      setCount(end);
      return;
    }

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      
      const easeOut = 1 - Math.pow(1 - percentage, 3);
      setCount(Math.floor(endValue * easeOut));

      if (percentage < 1) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrameId);
  }, [end, duration]);

  return <span>{count}{suffix}</span>;
};

const Hero = () => {
  const services = [
    { id: 1, name: 'WEB DESIGN & DEV', icon: FaLaptopCode },
    { id: 2, name: 'MOBILE APPS', icon: FaMobileAlt },
    { id: 3, name: 'AGENTIC AI', icon: FaRobot },
    { id: 4, name: 'WORDPRESS', icon: FaWordpress },
  ]

  return (
    <>
      <section className="hero">
        <div className="hero-container">
          {/* Badge */}
          <div className="hero-badge">
            <span className="badge-icon">●</span>
            <span className="badge-text">Tech Riwaayat</span>
            <span className="badge-dot">●</span>
            <span className="badge-highlight">SOFTWARE HOUSE IN PAKISTAN</span>
          </div>

          {/* Main Heading */}
          <h1 className="hero-title">
            Software House in Pakistan for
            <br />
            <span className="highlight">Custom Software, POS</span> & Web Development
          </h1>

          {/* Tagline - Single Line */}
          <p className="hero-tagline">
            CUSTOM SOFTWARE · <span className="highlight">POS & INVENTORY</span> · <span className="normal">WEBSITES & MOBILE APPS</span>
          </p>

          {/* Description */}
          <p className="hero-description">
            Tech Riwaayat builds <strong>custom software</strong>, <strong>POS and inventory systems</strong>, <strong>ERP</strong>, <strong>websites</strong> and <strong>mobile apps</strong> for businesses across Pakistan. Tell us what slows your business down and we will show you a working solution, with a clear quote before we start.
          </p>

          {/* Service Badges */}
          <div className="service-badges">
            {services.map((service) => {
              const IconComponent = service.icon
              return (
                <div key={service.id} className="service-badge">
                  <span className="badge-icon"><IconComponent /></span>
                  <span className="badge-label">{service.name}</span>
                </div>
              )
            })}
          </div>

          {/* CTA Buttons */}
          <div className="hero-buttons">
            <Link to="/contact" className="btn btn-primary" style={{textDecoration: 'none'}}>
              Get a Free Quote
              <FaArrowRight className="arrow-icon" style={{marginLeft: '6px'}} />
            </Link>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn btn-secondary" style={{textDecoration: 'none'}}>
              <FaComments className="icon" style={{marginRight: '6px'}} /> Talk on WhatsApp
            </a>
          </div>

          {/* Trust Badge */}
          <div className="trust-badge">
            <span className="trust-text">
              <span className="trust-main-text"><span className="trust-icon">★</span> SERVING BUSINESSES ACROSS PAKISTAN</span>
            </span>
          </div>

          {/* Inline Stats */}
          <div className="hero-inline-stats">
            <div className="inline-stat">
              <span className="stat-num"><AnimatedCounter end="30" suffix="+" /></span>
              <span className="stat-text">Projects Completed</span>
            </div>
            <div className="stat-divider"></div>
            <div className="inline-stat">
              <span className="stat-num"><AnimatedCounter end="98" suffix="%" /></span>
              <span className="stat-text">Client Satisfaction</span>
            </div>
            <div className="stat-divider"></div>
            <div className="inline-stat">
              <span className="stat-num"><AnimatedCounter end="500" suffix="k+" /></span>
              <span className="stat-text">Lines of Code</span>
            </div>
            <div className="stat-divider"></div>
            <div className="inline-stat">
              <span className="stat-num"><AnimatedCounter end="3" suffix="+" /></span>
              <span className="stat-text">Countries Served</span>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Hero
